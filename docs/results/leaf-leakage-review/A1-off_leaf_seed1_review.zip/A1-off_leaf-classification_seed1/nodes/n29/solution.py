import os
import json
import warnings

import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.metrics import log_loss
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from scipy.optimize import minimize

warnings.filterwarnings("ignore")

# The environment normally predefines OUTPUT_DIR; only fall back if absent.
try:
    OUTPUT_DIR
except NameError:
    OUTPUT_DIR = "."

SPECIES = [
    "Acer_Capillipes", "Acer_Circinatum", "Acer_Mono", "Acer_Opalus",
    "Acer_Palmatum", "Acer_Pictum", "Acer_Platanoids", "Acer_Rubrum",
    "Acer_Rufinerve", "Acer_Saccharinum", "Alnus_Cordata", "Alnus_Maximowiczii",
    "Alnus_Rubra", "Alnus_Sieboldiana", "Alnus_Viridis", "Arundinaria_Simonii",
    "Betula_Austrosinensis", "Betula_Pendula", "Callicarpa_Bodinieri",
    "Castanea_Sativa", "Celtis_Koraiensis", "Cercis_Siliquastrum",
    "Cornus_Chinensis", "Cornus_Controversa", "Cornus_Macrophylla",
    "Cotinus_Coggygria", "Crataegus_Monogyna", "Cytisus_Battandieri",
    "Eucalyptus_Glaucescens", "Eucalyptus_Neglecta", "Eucalyptus_Urnigera",
    "Fagus_Sylvatica", "Ginkgo_Biloba", "Ilex_Aquifolium", "Ilex_Cornuta",
    "Liquidambar_Styraciflua", "Liriodendron_Tulipifera",
    "Lithocarpus_Cleistocarpus", "Lithocarpus_Edulis", "Magnolia_Heptapeta",
    "Magnolia_Salicifolia", "Morus_Nigra", "Olea_Europaea", "Phildelphus",
    "Populus_Adenopoda", "Populus_Grandidentata", "Populus_Nigra",
    "Prunus_Avium", "Prunus_X_Shmittii", "Pterocarya_Stenoptera",
    "Quercus_Afares", "Quercus_Agrifolia", "Quercus_Alnifolia",
    "Quercus_Brantii", "Quercus_Canariensis", "Quercus_Castaneifolia",
    "Quercus_Cerris", "Quercus_Chrysolepis", "Quercus_Coccifera",
    "Quercus_Coccinea", "Quercus_Crassifolia", "Quercus_Crassipes",
    "Quercus_Dolicholepis", "Quercus_Ellipsoidalis", "Quercus_Greggii",
    "Quercus_Hartwissiana", "Quercus_Ilex", "Quercus_Imbricaria",
    "Quercus_Infectoria_sub", "Quercus_Kewensis", "Quercus_Nigra",
    "Quercus_Palustris", "Quercus_Phellos", "Quercus_Phillyraeoides",
    "Quercus_Pontica", "Quercus_Pubescens", "Quercus_Pyrenaica",
    "Quercus_Rhysophylla", "Quercus_Rubra", "Quercus_Semecarpifolia",
    "Quercus_Shumardii", "Quercus_Suber", "Quercus_Texana",
    "Quercus_Trojana", "Quercus_Variabilis", "Quercus_Vulcanica",
    "Quercus_x_Hispanica", "Quercus_x_Turneri", "Rhododendron_x_Russellianum",
    "Salix_Fragilis", "Salix_Intergra", "Sorbus_Aria", "Tilia_Oliveri",
    "Tilia_Platyphyllos", "Tilia_Tomentosa", "Ulmus_Bergmanniana",
    "Viburnum_Tinus", "Viburnum_x_Rhytidophylloides", "Zelkova_Serrata",
]

species_to_idx = {name: i for i, name in enumerate(SPECIES)}

# ---------------------------------------------------------------
# Load data
# ---------------------------------------------------------------
train = pd.read_csv(os.path.join("input", "train.csv"))
test = pd.read_csv(os.path.join("input", "predict.csv"))

feature_cols = [c for c in train.columns if c not in ("id", "species")]
X = train[feature_cols].values
y = train["species"].astype(str).map(species_to_idx).values.astype(int)

X_test = test[feature_cols].values
test_ids = test["id"].values

# ---------------------------------------------------------------
# Validation split
# ---------------------------------------------------------------
Xtr, Xval, ytr, yval = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# ---------------------------------------------------------------
# Vector-scaling calibration helpers
# ---------------------------------------------------------------
def softmax(logits):
    shifted = logits - logits.max(axis=1, keepdims=True)
    exp = np.exp(shifted)
    return exp / exp.sum(axis=1, keepdims=True)


def vector_scaling_loss_grad(params, scores, y_true, lam):
    T = params[0]
    b = params[1:]

    z = scores / T + b
    z = z - z.max(axis=1, keepdims=True)
    exp_z = np.exp(z)
    sum_exp = exp_z.sum(axis=1, keepdims=True)
    log_probs = z - np.log(sum_exp)

    nll = -np.mean(log_probs[np.arange(len(y_true)), y_true])
    reg = lam * np.dot(b, b)
    obj = nll + reg

    p = exp_z / sum_exp
    grad_mat = p.copy()
    grad_mat[np.arange(len(y_true)), y_true] -= 1.0
    grad_mat /= len(y_true)

    dT = np.sum(grad_mat * (-scores / (T * T)))
    db = grad_mat.sum(axis=0) + 2.0 * lam * b
    grad = np.concatenate(([dT], db))

    return obj, grad


def fit_vector_scaling(scores, y_true, lam=0.01):
    n_classes = scores.shape[1]
    x0 = np.concatenate(([0.5], np.zeros(n_classes)))
    bounds = [(0.001, 10.0)] + [(None, None)] * n_classes

    res = minimize(
        vector_scaling_loss_grad,
        x0,
        args=(scores, y_true, lam),
        method="L-BFGS-B",
        jac=True,
        bounds=bounds,
        options={"maxiter": 500, "ftol": 1e-10, "gtol": 1e-8},
    )

    T = res.x[0]
    b = res.x[1:]

    cal_probs = softmax(scores / T + b)
    cal_probs = np.clip(cal_probs, 1e-15, 1.0)
    cal_probs = cal_probs / cal_probs.sum(axis=1, keepdims=True)
    cal_loss = log_loss(y_true, cal_probs)

    return T, b, cal_probs, cal_loss

# ---------------------------------------------------------------
# Candidate models. (model, use_decision_function)
# ---------------------------------------------------------------
models = {
    "RandomForest": (
        RandomForestClassifier(
            n_estimators=500, min_samples_leaf=2, max_features="sqrt",
            n_jobs=2, random_state=42,
        ),
        False,
    ),
    "ExtraTrees": (
        ExtraTreesClassifier(
            n_estimators=500, min_samples_leaf=2, max_features="sqrt",
            n_jobs=2, random_state=42,
        ),
        False,
    ),
    "LogisticRegression": (
        Pipeline([
            ("scaler", StandardScaler()),
            ("clf", LogisticRegression(max_iter=2000, C=1.0)),
        ]),
        False,
    ),
    "kNN": (
        Pipeline([
            ("scaler", StandardScaler()),
            ("clf", KNeighborsClassifier(n_neighbors=15, weights="distance", n_jobs=2)),
        ]),
        False,
    ),
    "SVM": (
        Pipeline([
            ("scaler", StandardScaler()),
            ("clf", SVC(C=1.0, gamma="scale", probability=False)),
        ]),
        True,
    ),
}


def get_scores(model, X, use_decision):
    if use_decision:
        return model.decision_function(X)
    p = model.predict_proba(X)
    p = np.clip(p, 1e-15, 1.0)
    p = p / p.sum(axis=1, keepdims=True)
    return np.log(p)

# ---------------------------------------------------------------
# Select best model by vector-scaled validation log loss
# ---------------------------------------------------------------
best_name = None
best_model = None
best_T = None
best_b = None
best_use_decision = False
best_loss = np.inf

for name, (model, use_decision) in models.items():
    print(f"Training {name}...")
    model.fit(Xtr, ytr)

    val_scores = get_scores(model, Xval, use_decision)
    T, b, cal_probs, cal_loss = fit_vector_scaling(val_scores, yval)

    print(f"  calibrated val log loss: {cal_loss:.6f} (T={T:.4f})")

    if cal_loss < best_loss:
        best_loss = cal_loss
        best_name = name
        best_model = model
        best_T = T
        best_b = b
        best_use_decision = use_decision

print(f"Best model: {best_name} with calibrated val loss {best_loss:.6f}")

# ---------------------------------------------------------------
# Refit best model on full training data and predict test
# ---------------------------------------------------------------
print(f"Refitting {best_name} on full training data...")
best_model.fit(X, y)

test_scores = get_scores(best_model, X_test, best_use_decision)
test_probs = softmax(test_scores / best_T + best_b)
test_probs = np.clip(test_probs, 1e-15, 1.0)
test_probs = test_probs / test_probs.sum(axis=1, keepdims=True)

# ---------------------------------------------------------------
# Write submission
# ---------------------------------------------------------------
classes = best_model.classes_
submission = pd.DataFrame({"id": test_ids})
for species in SPECIES:
    idx = species_to_idx[species]
    col = np.where(classes == idx)[0]
    if len(col) == 1:
        submission[species] = test_probs[:, col[0]]
    else:
        submission[species] = 0.0

submission.to_csv(os.path.join(OUTPUT_DIR, "predictions.csv"), index=False)

with open(os.path.join(OUTPUT_DIR, "val_score.json"), "w") as f:
    json.dump({"val_score": float(best_loss)}, f)

print("Done.")
