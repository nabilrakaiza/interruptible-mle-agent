import os
import json

import numpy as np
import pandas as pd
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.metrics import log_loss
from sklearn.model_selection import train_test_split

# OUTPUT_DIR is provided by the harness.

train = pd.read_csv("input/train.csv")
test = pd.read_csv("input/predict.csv")

feature_cols = [c for c in train.columns if c not in ("id", "species")]
X = train[feature_cols].to_numpy(dtype=np.float64)
y = train["species"].astype(str).to_numpy()
X_test = test[feature_cols].to_numpy(dtype=np.float64)

species_list = sorted(pd.unique(y))

X_train, X_val, y_train, y_val = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

model = ExtraTreesClassifier(
    n_estimators=500,
    min_samples_leaf=2,
    max_features="sqrt",
    random_state=42,
    n_jobs=-1,
)

model.fit(X_train, y_train)
val_proba = pd.DataFrame(
    model.predict_proba(X_val), columns=model.classes_
).reindex(columns=species_list).fillna(0.0).to_numpy()
val_score = float(log_loss(y_val, val_proba, labels=species_list))

model.fit(X, y)
test_proba = pd.DataFrame(
    model.predict_proba(X_test), columns=model.classes_
).reindex(columns=species_list).fillna(0.0).to_numpy()
test_proba = test_proba / test_proba.sum(axis=1, keepdims=True)

submission = pd.DataFrame(test_proba, columns=species_list)
submission.insert(0, "id", test["id"].to_numpy())

os.makedirs(OUTPUT_DIR, exist_ok=True)
submission.to_csv(os.path.join(OUTPUT_DIR, "predictions.csv"), index=False)

with open(os.path.join(OUTPUT_DIR, "val_score.json"), "w") as f:
    json.dump({"val_score": val_score}, f)
