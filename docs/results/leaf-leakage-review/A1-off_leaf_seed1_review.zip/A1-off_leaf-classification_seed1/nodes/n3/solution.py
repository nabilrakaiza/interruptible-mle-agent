if "OUTPUT_DIR" not in globals():
    OUTPUT_DIR = "/output"

import os
import json

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import log_loss
from sklearn.model_selection import train_test_split

SPECIES = [
    "Acer_Capillipes", "Acer_Circinatum", "Acer_Mono", "Acer_Opalus",
    "Acer_Palmatum", "Acer_Pictum", "Acer_Platanoids", "Acer_Rubrum",
    "Acer_Rufinerve", "Acer_Saccharinum", "Alnus_Cordata",
    "Alnus_Maximowiczii", "Alnus_Rubra", "Alnus_Sieboldiana",
    "Alnus_Viridis", "Arundinaria_Simonii", "Betula_Austrosinensis",
    "Betula_Pendula", "Callicarpa_Bodinieri", "Castanea_Sativa",
    "Celtis_Koraiensis", "Cercis_Siliquastrum", "Cornus_Chinensis",
    "Cornus_Controversa", "Cornus_Macrophylla", "Cotinus_Coggygria",
    "Crataegus_Monogyna", "Cytisus_Battandieri", "Eucalyptus_Glaucescens",
    "Eucalyptus_Neglecta", "Eucalyptus_Urnigera", "Fagus_Sylvatica",
    "Ginkgo_Biloba", "Ilex_Aquifolium", "Ilex_Cornuta",
    "Liquidambar_Styraciflua", "Liriodendron_Tulipifera",
    "Lithocarpus_Cleistocarpus", "Lithocarpus_Edulis", "Magnolia_Heptapeta",
    "Magnolia_Salicifolia", "Morus_Nigra", "Olea_Europaea", "Phildelphus",
    "Populus_Adenopoda", "Populus_Grandidentata", "Populus_Nigra",
    "Prunus_Avium", "Prunus_X_Shmittii", "Pterocarya_Stenoptera",
    "Quercus_Afares", "Quercus_Agrifolia", "Quercus_Alnifolia",
    "Quercus_Brantii", "Quercus_Canariensis", "Quercus_Castaneifolia",
    "Quercus_Cerris", "Quercus_Chrysolepis", "Quercus_Coccifera",
    "Quercus_Coccinea", "Quercus_Crassifolia", "Quercus_Crassipes",
    "Quercus_Dolicholepis", "Quercus_Ellipsoidalis", "Quercus_Greggii",
    "Quercus_Hartwissiana", "Quercus_Ilex", "Quercus_Imbricaria",
    "Quercus_Infectoria_sub", "Quercus_Kewensis", "Quercus_Nigra",
    "Quercus_Palustris", "Quercus_Phellos", "Quercus_Phillyraeoides",
    "Quercus_Pontica", "Quercus_Pubescens", "Quercus_Pyrenaica",
    "Quercus_Rhysophylla", "Quercus_Rubra", "Quercus_Semecarpifolia",
    "Quercus_Shumardii", "Quercus_Suber", "Quercus_Texana",
    "Quercus_Trojana", "Quercus_Variabilis", "Quercus_Vulcanica",
    "Quercus_x_Hispanica", "Quercus_x_Turneri", "Rhododendron_x_Russellianum",
    "Salix_Fragilis", "Salix_Intergra", "Sorbus_Aria", "Tilia_Oliveri",
    "Tilia_Platyphyllos", "Tilia_Tomentosa", "Ulmus_Bergmanniana",
    "Viburnum_Tinus", "Viburnum_x_Rhytidophylloides", "Zelkova_Serrata",
]

os.makedirs(OUTPUT_DIR, exist_ok=True)

train_df = pd.read_csv(os.path.join("input", "train.csv"))
predict_df = pd.read_csv(os.path.join("input", "predict.csv"))

feature_cols = [c for c in train_df.columns if c not in ("id", "species")]
X = train_df[feature_cols]
y = train_df["species"].astype(str)

X_train, X_val, y_train, y_val = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)


def make_model():
    return HistGradientBoostingClassifier(
        max_iter=80,
        learning_rate=0.1,
        max_depth=3,
        max_leaf_nodes=None,
        min_samples_leaf=5,
        l2_regularization=1.0,
        early_stopping=False,
        random_state=42,
    )


model = make_model()
model.fit(X_train, y_train)

val_proba = model.predict_proba(X_val)
val_proba_df = pd.DataFrame(val_proba, columns=model.classes_).reindex(columns=SPECIES)
val_loss = log_loss(y_val, val_proba_df.values, labels=SPECIES)

final_model = make_model()
final_model.fit(X, y)

test_proba = final_model.predict_proba(predict_df[feature_cols])
test_proba_df = pd.DataFrame(test_proba, columns=final_model.classes_).reindex(columns=SPECIES)
test_proba = np.clip(test_proba_df.values, 1e-15, 1.0)
test_proba = test_proba / test_proba.sum(axis=1, keepdims=True)

submission = predict_df[["id"]].reset_index(drop=True)
submission = pd.concat(
    [submission, pd.DataFrame(test_proba, columns=SPECIES)],
    axis=1,
)
submission.to_csv(os.path.join(OUTPUT_DIR, "predictions.csv"), index=False)

with open(os.path.join(OUTPUT_DIR, "val_score.json"), "w") as f:
    json.dump({"val_score": float(val_loss)}, f)
