import os
import json
import warnings

import numpy as np
import pandas as pd

from PIL import Image
from scipy.ndimage import binary_erosion, distance_transform_edt
from scipy.spatial import ConvexHull
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.metrics import log_loss
from sklearn.base import clone
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.neighbors import KNeighborsClassifier
from sklearn.kernel_approximation import RBFSampler
from sklearn.neural_network import MLPClassifier
from sklearn.decomposition import PCA

warnings.filterwarnings("ignore")

try:
    OUTPUT_DIR
except NameError:
    OUTPUT_DIR = "."

SPECIES = [
    "Acer_Capillipes", "Acer_Circinatum", "Acer_Mono", "Acer_Opalus",
    "Acer_Palmatum", "Acer_Pictum", "Acer_Platanoids", "Acer_Rubrum",
    "Acer_Rufinerve", "Acer_Saccharinum", "Alnus_Cordata", "Alnus_Maximowiczii",
    "Alnus_Rubra", "Alnus_Sieboldiana", "Alnus_Viridis", "Arundinaria_Simonii",
    "Betula_Austrosinensis", "Betula_Pendula", "Callicarpa_Bodinieri",
    "Castanea_Sativa", "Celtis_Koraiensis", "Cercis_Siliquastrum",
    "Cornus_Chinensis", "Cornus_Controversa", "Cornus_Macrophylla",
    "Cotinus_Coggygria", "Crataegus_Monogyna", "Cytisus_Battandieri",
    "Eucalyptus_Glaucescens", "Eucalyptus_Neglecta", "Eucalyptus_Urnigera",
    "Fagus_Sylvatica", "Ginkgo_Biloba", "Ilex_Aquifolium", "Ilex_Cornuta",
    "Liquidambar_Styraciflua", "Liriodendron_Tulipifera",
    "Lithocarpus_Cleistocarpus", "Lithocarpus_Edulis", "Magnolia_Heptapeta",
    "Magnolia_Salicifolia", "Morus_Nigra", "Olea_Europaea", "Phildelphus",
    "Populus_Adenopoda", "Populus_Grandidentata", "Populus_Nigra",
    "Prunus_Avium", "Prunus_X_Shmittii", "Pterocarya_Stenoptera",
    "Quercus_Afares", "Quercus_Agrifolia", "Quercus_Alnifolia",
    "Quercus_Brantii", "Quercus_Canariensis", "Quercus_Castaneifolia",
    "Quercus_Cerris", "Quercus_Chrysolepis", "Quercus_Coccifera",
    "Quercus_Coccinea", "Quercus_Crassifolia", "Quercus_Crassipes",
    "Quercus_Dolicholepis", "Quercus_Ellipsoidalis", "Quercus_Greggii",
    "Quercus_Hartwissiana", "Quercus_Ilex", "Quercus_Imbricaria",
    "Quercus_Infectoria_sub", "Quercus_Kewensis", "Quercus_Nigra",
    "Quercus_Palustris", "Quercus_Phellos", "Quercus_Phillyraeoides",
    "Quercus_Pontica", "Quercus_Pubescens", "Quercus_Pyrenaica",
    "Quercus_Rhysophylla", "Quercus_Rubra", "Quercus_Semecarpifolia",
    "Quercus_Shumardii", "Quercus_Suber", "Quercus_Texana",
    "Quercus_Trojana", "Quercus_Variabilis", "Quercus_Vulcanica",
    "Quercus_x_Hispanica", "Quercus_x_Turneri", "Rhododendron_x_Russellianum",
    "Salix_Fragilis", "Salix_Intergra", "Sorbus_Aria", "Tilia_Oliveri",
    "Tilia_Platyphyllos", "Tilia_Tomentosa", "Ulmus_Bergmanniana",
    "Viburnum_Tinus", "Viburnum_x_Rhytidophylloides", "Zelkova_Serrata",
]

species_to_idx = {name: i for i, name in enumerate(SPECIES)}


# ---------------------------------------------------------------
# Image feature extraction
# ---------------------------------------------------------------
def _center_of_mass(crop):
    ys, xs = np.nonzero(crop)
    if ys.size == 0:
        return 0.0, 0.0
    return float(ys.mean()), float(xs.mean())


def _moments_central(crop, cy, cx, order=3):
    h, w = crop.shape
    y = np.arange(h, dtype=np.float64) - cy
    x = np.arange(w, dtype=np.float64) - cx
    yp = np.ones((order + 1, h), dtype=np.float64)
    xp = np.ones((order + 1, w), dtype=np.float64)
    for p in range(1, order + 1):
        yp[p] = yp[p - 1] * y
        xp[p] = xp[p - 1] * x
    return yp @ crop.astype(np.float64) @ xp.T


def extract_image_features(path):
    default = np.zeros(24, dtype=np.float64)
    if not os.path.exists(path):
        return default
    try:
        with Image.open(path) as im:
            img = np.array(im.convert("L"))
    except Exception:
        return default
    if img.size == 0:
        return default

    mask = img < 128
    if mask.mean() > 0.5:
        mask = ~mask

    coords = np.argwhere(mask)
    if coords.size == 0:
        return default

    min_y, max_y = coords[:, 0].min(), coords[:, 0].max()
    min_x, max_x = coords[:, 1].min(), coords[:, 1].max()
    crop = mask[min_y:max_y + 1, min_x:max_x + 1]
    h, w = crop.shape
    area = float(crop.sum())
    if area <= 0:
        return default

    bbox_area = float(h * w)
    extent = area / bbox_area
    aspect = w / h if h > 0 else 1.0

    eroded = binary_erosion(crop, iterations=1)
    boundary_mask = crop & ~eroded
    perimeter = float(boundary_mask.sum())

    cy, cx = _center_of_mass(crop)
    mu = _moments_central(crop, cy, cx, 3)

    radial_feats = np.zeros(4, dtype=np.float64)
    boundary_coords = np.argwhere(boundary_mask).astype(np.float64)
    if boundary_coords.shape[0] >= 3:
        dy = boundary_coords[:, 0] - cy
        dx = boundary_coords[:, 1] - cx
        r = np.sqrt(dy * dy + dx * dx)
        rmax = r.max()
        if rmax > 1e-12:
            rn = r / rmax
            rmean = rn.mean()
            rstd = rn.std()
            if rstd > 1e-12:
                rskew = float((((rn - rmean) ** 3).mean()) / (rstd ** 3))
                rkurt = float((((rn - rmean) ** 4).mean()) / (rstd ** 4) - 3.0)
            else:
                rskew = 0.0
                rkurt = 0.0
            radial_feats = np.array([rmean, rstd, rskew, rkurt], dtype=np.float64)

    thickness_feats = np.zeros(4, dtype=np.float64)
    edt = distance_transform_edt(crop)
    edt_max = edt.max()
    if edt_max > 1e-12:
        dn = edt / edt_max
        dmean = dn.mean()
        dstd = dn.std()
        if dstd > 1e-12:
            dskew = float((((dn - dmean) ** 3).mean()) / (dstd ** 3))
            dkurt = float((((dn - dmean) ** 4).mean()) / (dstd ** 4) - 3.0)
        else:
            dskew = 0.0
            dkurt = 0.0
        thickness_feats = np.array([dmean, dstd, dskew, dkurt], dtype=np.float64)

    mu20, mu02, mu11 = mu[2, 0], mu[0, 2], mu[1, 1]
    cov00, cov11 = mu20 / area, mu02 / area
    cov01 = mu11 / area
    trace = cov00 + cov11
    disc = 0.25 * (cov00 - cov11) ** 2 + cov01 ** 2
    major = np.sqrt(max(0.0, 0.5 * (trace + np.sqrt(disc))))
    minor = np.sqrt(max(0.0, 0.5 * (trace - np.sqrt(disc))))
    ecc = 0.0
    if major > 1e-12:
        ecc = np.sqrt(max(0.0, 1.0 - (minor / major) ** 2))

    nu = {}
    for p in range(4):
        for q in range(4 - p):
            if p + q >= 2:
                nu[(p, q)] = mu[p, q] / (area ** (1.0 + (p + q) / 2.0))

    n20, n02, n11 = nu[(2, 0)], nu[(0, 2)], nu[(1, 1)]
    n30, n12 = nu[(3, 0)], nu[(1, 2)]
    n21, n03 = nu[(2, 1)], nu[(0, 3)]
    hu = np.zeros(7)
    hu[0] = n20 + n02
    hu[1] = (n20 - n02) ** 2 + 4 * n11 ** 2
    hu[2] = (n30 - 3 * n12) ** 2 + (3 * n21 - n03) ** 2
    hu[3] = (n30 + n12) ** 2 + (n21 + n03) ** 2
    hu[4] = ((n30 - 3 * n12) * (n30 + n12) *
             ((n30 + n12) ** 2 - 3 * (n21 + n03) ** 2) +
             (3 * n21 - n03) * (n21 + n03) *
             (3 * (n30 + n12) ** 2 - (n21 + n03) ** 2))
    hu[5] = ((n20 - n02) * ((n30 + n12) ** 2 - (n21 + n03) ** 2) +
             4 * n11 * (n30 + n12) * (n21 + n03))
    hu[6] = ((3 * n21 - n03) * (n30 + n12) *
             ((n30 + n12) ** 2 - 3 * (n21 + n03) ** 2) -
             (n30 - 3 * n12) * (n21 + n03) *
             (3 * (n30 + n12) ** 2 - (n21 + n03) ** 2))
    hu_log = np.sign(hu) * np.log10(np.abs(hu) + 1e-10)

    hull_area = bbox_area
    hull_perim = float(2.0 * (h + w))
    if boundary_mask.sum() >= 3:
        try:
            hull = ConvexHull(boundary_coords)
            hull_area = float(hull.volume)
            verts = boundary_coords[hull.vertices]
            diffs = np.diff(np.vstack([verts, verts[:1]]), axis=0)
            hull_perim = float(np.sqrt((diffs ** 2).sum(axis=1)).sum())
        except Exception:
            hull_area = bbox_area
            hull_perim = float(2.0 * (h + w))

    solidity = float(np.clip(area / hull_area, 0.0, 1.0)) if hull_area > 0 else 1.0
    compactness = float(np.clip(4.0 * np.pi * area / (perimeter * perimeter), 0.0, 1.0)) if perimeter > 0 else 0.0
    roughness = float(np.clip(hull_perim / perimeter, 0.0, 10.0)) if perimeter > 0 else 1.0
    hull_extent = float(np.clip(hull_area / bbox_area, 0.0, 1.0)) if bbox_area > 0 else 0.0

    return np.array([
        np.log1p(area),
        np.log1p(perimeter),
        aspect,
        extent,
        ecc,
        hu_log[0],
        hu_log[1],
        hu_log[2],
        hu_log[3],
        hu_log[4],
        hu_log[5],
        hu_log[6],
        solidity,
        compactness,
        roughness,
        hull_extent,
        radial_feats[0],
        radial_feats[1],
        radial_feats[2],
        radial_feats[3],
        thickness_feats[0],
        thickness_feats[1],
        thickness_feats[2],
        thickness_feats[3],
    ], dtype=np.float64)


def load_image_features(df):
    feats = np.zeros((len(df), 24), dtype=np.float64)
    for i, img_id in enumerate(df["id"]):
        path = os.path.join("input", "images", f"{int(img_id)}.jpg")
        feats[i] = extract_image_features(path)
    return feats


# ---------------------------------------------------------------
# Raw pixel feature extraction
# ---------------------------------------------------------------
def extract_pixel_features(path, size=32):
    default = np.zeros(size * size, dtype=np.float64)
    if not os.path.exists(path):
        return default
    try:
        with Image.open(path) as im:
            img = np.array(im.convert("L"))
    except Exception:
        return default
    if img.size == 0:
        return default

    mask = img < 128
    if mask.mean() > 0.5:
        mask = ~mask

    coords = np.argwhere(mask)
    if coords.size == 0:
        return default

    min_y, max_y = coords[:, 0].min(), coords[:, 0].max()
    min_x, max_x = coords[:, 1].min(), coords[:, 1].max()
    crop = mask[min_y:max_y + 1, min_x:max_x + 1].astype(np.uint8) * 255
    h, w = crop.shape

    border = 1
    max_dim = size - 2 * border
    scale = min(max_dim / w, max_dim / h)
    new_w = max(1, int(round(w * scale)))
    new_h = max(1, int(round(h * scale)))

    pil_crop = Image.fromarray(crop)
    pil_resized = pil_crop.resize((new_w, new_h), Image.Resampling.LANCZOS)
    resized = np.array(pil_resized)

    leaf = resized > 128
    canvas = np.zeros((size, size), dtype=np.float64)
    y_off = (size - new_h) // 2
    x_off = (size - new_w) // 2
    canvas[y_off:y_off + new_h, x_off:x_off + new_w] = leaf.astype(np.float64)
    return canvas.flatten()


def load_pixel_features(df, size=32):
    feats = np.zeros((len(df), size * size), dtype=np.float64)
    for i, img_id in enumerate(df["id"]):
        path = os.path.join("input", "images", f"{int(img_id)}.jpg")
        feats[i] = extract_pixel_features(path, size)
    return feats


# ---------------------------------------------------------------
# Load data
# ---------------------------------------------------------------
train = pd.read_csv(os.path.join("input", "train.csv"))
test = pd.read_csv(os.path.join("input", "predict.csv"))

feature_cols = [c for c in train.columns if c not in ("id", "species")]
X_pre = train[feature_cols].values.astype(np.float64)
y = train["species"].astype(str).map(species_to_idx).values.astype(int)

X_test_pre = test[feature_cols].values.astype(np.float64)
test_ids = test["id"].values

print("Extracting image features...")
img_train = load_image_features(train)
missing_train = np.all(img_train == 0, axis=1)
if missing_train.any():
    img_train_mean = img_train[~missing_train].mean(axis=0)
    img_train[missing_train] = img_train_mean
else:
    img_train_mean = img_train.mean(axis=0)

img_test = load_image_features(test)
missing_test = np.all(img_test == 0, axis=1)
if missing_test.any():
    img_test[missing_test] = img_train_mean

X = np.hstack([X_pre, img_train])
X_test = np.hstack([X_test_pre, img_test])

print("Extracting pixel features...")
pixel_train = load_pixel_features(train)
pixel_test = load_pixel_features(test)
pixel_mean = pixel_train.mean(axis=0)
missing_pix_train = np.all(pixel_train == 0, axis=1)
if missing_pix_train.any():
    pixel_train[missing_pix_train] = pixel_mean
missing_pix_test = np.all(pixel_test == 0, axis=1)
if missing_pix_test.any():
    pixel_test[missing_pix_test] = pixel_mean

# ---------------------------------------------------------------
# Validation split
# ---------------------------------------------------------------
Xtr, Xval, ytr, yval, Ptr, Pval = train_test_split(
    X, y, pixel_train, test_size=0.2, random_state=42, stratify=y
)


# ---------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------
def safe_probs(p):
    p = np.clip(p, 1e-15, 1.0)
    return p / p.sum(axis=1, keepdims=True)


def oof_probabilities(estimator, X, y, n_splits=5, random_states=(42, 2024, 2025)):
    proba_sum = None
    n_classes = len(np.unique(y))
    for rs in random_states:
        skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=rs)
        proba = np.zeros((X.shape[0], n_classes))
        for train_idx, val_idx in skf.split(X, y):
            est = clone(estimator)
            est.fit(X[train_idx], y[train_idx])
            p = est.predict_proba(X[val_idx])
            proba[val_idx] = safe_probs(p)
        if proba_sum is None:
            proba_sum = proba
        else:
            proba_sum += proba
    return proba_sum / len(random_states)


# ---------------------------------------------------------------
# Base models (fast and complementary)
# ---------------------------------------------------------------
lda = LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto")

lr = Pipeline([
    ("scaler", StandardScaler()),
    ("clf", LogisticRegression(solver="lbfgs", max_iter=2000, C=1.0, random_state=42)),
])

knn = Pipeline([
    ("scaler", StandardScaler()),
    ("clf", KNeighborsClassifier(n_neighbors=7, weights="distance", n_jobs=-1)),
])

gamma_rbf = 1.0 / X.shape[1]
rbf_lr = Pipeline([
    ("scaler", StandardScaler()),
    ("rbf", RBFSampler(gamma=gamma_rbf, n_components=200, random_state=42)),
    ("clf", LogisticRegression(solver="lbfgs", max_iter=2000, C=1.0, random_state=42)),
])

mlp = Pipeline([
    ("scaler", StandardScaler()),
    ("clf", MLPClassifier(
        hidden_layer_sizes=(64,),
        activation="relu",
        alpha=0.1,
        batch_size="auto",
        learning_rate_init=0.001,
        max_iter=1000,
        early_stopping=True,
        n_iter_no_change=10,
        validation_fraction=0.1,
        random_state=42,
    )),
])

pixel_lda = Pipeline([
    ("scaler", StandardScaler()),
    ("pca", PCA(n_components=100, random_state=42)),
    ("clf", LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto")),
])

model_specs = [
    ("LDA", lda, Xtr, Xval),
    ("LR", lr, Xtr, Xval),
    ("KNN", knn, Xtr, Xval),
    ("RBF-LR", rbf_lr, Xtr, Xval),
    ("MLP", mlp, Xtr, Xval),
    ("PixLDA", pixel_lda, Ptr, Pval),
]

# ---------------------------------------------------------------
# Fit stacked calibration on out-of-fold probabilities
# ---------------------------------------------------------------
print("Computing repeated out-of-fold probabilities for the validation split...")
stack_train_parts = []
for name, model, data_tr, _ in model_specs:
    p = oof_probabilities(model, data_tr, ytr)
    print(f"  OOF {name} log loss: {log_loss(ytr, p):.6f}")
    stack_train_parts.append(p)

stack_train = np.hstack(stack_train_parts)

meta = Pipeline([
    ("scaler", StandardScaler()),
    ("clf", LogisticRegression(solver="lbfgs", C=0.1, max_iter=2000, random_state=42)),
])
meta.fit(stack_train, ytr)

# ---------------------------------------------------------------
# Honest validation score
# ---------------------------------------------------------------
val_parts = []
for _, model, data_tr, data_val in model_specs:
    est = clone(model).fit(data_tr, ytr)
    val_parts.append(safe_probs(est.predict_proba(data_val)))

stack_val = np.hstack(val_parts)
val_probs = safe_probs(meta.predict_proba(stack_val))
cal_loss = log_loss(yval, val_probs)
print(f"Stacked validation log loss: {cal_loss:.6f}")

# ---------------------------------------------------------------
# Refit stack on full training data and predict test
# ---------------------------------------------------------------
print("Fitting full-data stack for test predictions...")
full_specs = [
    ("LDA", lda, X, X_test),
    ("LR", lr, X, X_test),
    ("KNN", knn, X, X_test),
    ("RBF-LR", rbf_lr, X, X_test),
    ("MLP", mlp, X, X_test),
    ("PixLDA", pixel_lda, pixel_train, pixel_test),
]

full_parts = []
for _, model, data_full, _ in full_specs:
    full_parts.append(oof_probabilities(model, data_full, y))

stack_full = np.hstack(full_parts)
meta_full = clone(meta)
meta_full.fit(stack_full, y)

test_parts = []
for _, model, data_full, data_test in full_specs:
    est = clone(model).fit(data_full, y)
    test_parts.append(safe_probs(est.predict_proba(data_test)))

stack_test = np.hstack(test_parts)
test_probs = safe_probs(meta_full.predict_proba(stack_test))

# ---------------------------------------------------------------
# Write submission
# ---------------------------------------------------------------
submission = pd.DataFrame({"id": test_ids})
for i, species in enumerate(SPECIES):
    submission[species] = test_probs[:, i]

submission.to_csv(os.path.join(OUTPUT_DIR, "predictions.csv"), index=False)

with open(os.path.join(OUTPUT_DIR, "val_score.json"), "w") as f:
    json.dump({"val_score": float(cal_loss)}, f)

print("Done.")
