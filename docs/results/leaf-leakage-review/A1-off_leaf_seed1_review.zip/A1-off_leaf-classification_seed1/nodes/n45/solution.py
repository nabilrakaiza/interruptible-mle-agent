import os
import json
import warnings

import numpy as np
import pandas as pd

from PIL import Image
from scipy.ndimage import binary_erosion, distance_transform_edt
from scipy.spatial import ConvexHull

from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.metrics import log_loss
from sklearn.base import clone
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC

warnings.filterwarnings("ignore")

try:
    OUTPUT_DIR
except NameError:
    OUTPUT_DIR = "."

SPECIES = [
    "Acer_Capillipes", "Acer_Circinatum", "Acer_Mono", "Acer_Opalus",
    "Acer_Palmatum", "Acer_Pictum", "Acer_Platanoids", "Acer_Rubrum",
    "Acer_Rufinerve", "Acer_Saccharinum", "Alnus_Cordata", "Alnus_Maximowiczii",
    "Alnus_Rubra", "Alnus_Sieboldiana", "Alnus_Viridis", "Arundinaria_Simonii",
    "Betula_Austrosinensis", "Betula_Pendula", "Callicarpa_Bodinieri",
    "Castanea_Sativa", "Celtis_Koraiensis", "Cercis_Siliquastrum",
    "Cornus_Chinensis", "Cornus_Controversa", "Cornus_Macrophylla",
    "Cotinus_Coggygria", "Crataegus_Monogyna", "Cytisus_Battandieri",
    "Eucalyptus_Glaucescens", "Eucalyptus_Neglecta", "Eucalyptus_Urnigera",
    "Fagus_Sylvatica", "Ginkgo_Biloba", "Ilex_Aquifolium", "Ilex_Cornuta",
    "Liquidambar_Styraciflua", "Liriodendron_Tulipifera",
    "Lithocarpus_Cleistocarpus", "Lithocarpus_Edulis", "Magnolia_Heptapeta",
    "Magnolia_Salicifolia", "Morus_Nigra", "Olea_Europaea", "Phildelphus",
    "Populus_Adenopoda", "Populus_Grandidentata", "Populus_Nigra",
    "Prunus_Avium", "Prunus_X_Shmittii", "Pterocarya_Stenoptera",
    "Quercus_Afares", "Quercus_Agrifolia", "Quercus_Alnifolia",
    "Quercus_Brantii", "Quercus_Canariensis", "Quercus_Castaneifolia",
    "Quercus_Cerris", "Quercus_Chrysolepis", "Quercus_Coccifera",
    "Quercus_Coccinea", "Quercus_Crassifolia", "Quercus_Crassipes",
    "Quercus_Dolicholepis", "Quercus_Ellipsoidalis", "Quercus_Greggii",
    "Quercus_Hartwissiana", "Quercus_Ilex", "Quercus_Imbricaria",
    "Quercus_Infectoria_sub", "Quercus_Kewensis", "Quercus_Nigra",
    "Quercus_Palustris", "Quercus_Phellos", "Quercus_Phillyraeoides",
    "Quercus_Pontica", "Quercus_Pubescens", "Quercus_Pyrenaica",
    "Quercus_Rhysophylla", "Quercus_Rubra", "Quercus_Semecarpifolia",
    "Quercus_Shumardii", "Quercus_Suber", "Quercus_Texana",
    "Quercus_Trojana", "Quercus_Variabilis", "Quercus_Vulcanica",
    "Quercus_x_Hispanica", "Quercus_x_Turneri", "Rhododendron_x_Russellianum",
    "Salix_Fragilis", "Salix_Intergra", "Sorbus_Aria", "Tilia_Oliveri",
    "Tilia_Platyphyllos", "Tilia_Tomentosa", "Ulmus_Bergmanniana",
    "Viburnum_Tinus", "Viburnum_x_Rhytidophylloides", "Zelkova_Serrata",
]

species_to_idx = {name: i for i, name in enumerate(SPECIES)}
N_IMG_FEATURES = 31


def _stats(x):
    x = np.asarray(x, dtype=np.float64)
    if x.size == 0:
        return np.zeros(9)
    mean = x.mean()
    std = x.std()
    if std < 1e-12:
        skew = 0.0
        kurt = 0.0
    else:
        skew = float(((x - mean) ** 3).mean() / (std ** 3))
        kurt = float(((x - mean) ** 4).mean() / (std ** 4) - 3.0)
    q = np.percentile(x, [25, 50, 75])
    return np.array([mean, std, x.min(), q[0], q[1], q[2], x.max(), skew, kurt])


def _hu_features_from_coords(coords):
    n = float(coords.shape[0])
    if n == 0:
        return np.zeros(7)

    cy = coords[:, 0].mean()
    cx = coords[:, 1].mean()
    dy = coords[:, 0] - cy
    dx = coords[:, 1] - cx

    mu20 = float((dx * dx).sum())
    mu02 = float((dy * dy).sum())
    mu11 = float((dx * dy).sum())
    mu30 = float((dx * dx * dx).sum())
    mu12 = float((dx * dy * dy).sum())
    mu21 = float((dx * dx * dy).sum())
    mu03 = float((dy * dy * dy).sum())

    nu20 = mu20 / (n * n)
    nu02 = mu02 / (n * n)
    nu11 = mu11 / (n * n)

    m00_2_5 = n ** 2.5
    nu30 = mu30 / m00_2_5
    nu12 = mu12 / m00_2_5
    nu21 = mu21 / m00_2_5
    nu03 = mu03 / m00_2_5

    hu = np.zeros(7)
    hu[0] = nu20 + nu02
    hu[1] = (nu20 - nu02) ** 2 + 4.0 * nu11 ** 2
    hu[2] = (nu30 - 3.0 * nu12) ** 2 + (3.0 * nu21 - nu03) ** 2
    hu[3] = (nu30 + nu12) ** 2 + (nu21 + nu03) ** 2
    hu[4] = (
        (nu30 - 3.0 * nu12) * (nu30 + nu12)
        * ((nu30 + nu12) ** 2 - 3.0 * (nu21 + nu03) ** 2)
        + (3.0 * nu21 - nu03) * (nu21 + nu03)
        * (3.0 * (nu30 + nu12) ** 2 - (nu21 + nu03) ** 2)
    )
    hu[5] = (
        (nu20 - nu02) * ((nu30 + nu12) ** 2 - (nu21 + nu03) ** 2)
        + 4.0 * nu11 * (nu30 + nu12) * (nu21 + nu03)
    )
    hu[6] = (
        (3.0 * nu21 - nu03) * (nu30 + nu12)
        * ((nu30 + nu12) ** 2 - 3.0 * (nu21 + nu03) ** 2)
        - (nu30 - 3.0 * nu12) * (nu21 + nu03)
        * (3.0 * (nu30 + nu12) ** 2 - (nu21 + nu03) ** 2)
    )

    return np.sign(hu) * np.log1p(np.abs(hu))


def _image_features(mask):
    coords = np.argwhere(mask).astype(np.float64)
    n = coords.shape[0]
    if n == 0:
        return np.zeros(N_IMG_FEATURES)

    area = float(n)
    cy = coords[:, 0].mean()
    cx = coords[:, 1].mean()

    min_y, min_x = coords.min(axis=0)
    max_y, max_x = coords.max(axis=0)
    bbox_area = (max_y - min_y + 1.0) * (max_x - min_x + 1.0)
    extent = area / bbox_area if bbox_area > 0 else 0.0

    eroded = binary_erosion(mask, structure=np.ones((3, 3), dtype=bool))
    boundary = mask & ~eroded
    perimeter = float(boundary.sum())
    bpts = np.argwhere(boundary).astype(np.float64)

    hull_area = area
    if len(bpts) >= 3:
        try:
            hull = ConvexHull(bpts)
            pts = bpts[hull.vertices]
            hull_area = 0.5 * abs(
                np.dot(pts[:, 0], np.roll(pts[:, 1], 1))
                - np.dot(pts[:, 1], np.roll(pts[:, 0], 1))
            )
        except Exception:
            hull_area = area

    solidity = area / hull_area if hull_area > 0 else 1.0
    compactness = (perimeter * perimeter) / (4.0 * np.pi * area) if area > 0 else 0.0
    perimeter_norm = perimeter / np.sqrt(area) if area > 0 else 0.0

    dy = coords[:, 0] - cy
    dx = coords[:, 1] - cx
    mu20 = float((dx * dx).sum() / area)
    mu02 = float((dy * dy).sum() / area)
    mu11 = float((dx * dy).sum() / area)

    trace = mu20 + mu02
    disc = np.sqrt(max((mu20 - mu02) ** 2 + 4.0 * mu11 * mu11, 0.0))
    lam1 = (trace + disc) / 2.0
    lam2 = (trace - disc) / 2.0
    eccentricity = float(np.sqrt(max(1.0 - lam2 / lam1, 0.0))) if lam1 > 0 else 0.0

    hu = _hu_features_from_coords(coords)

    if len(bpts) > 0:
        bx = bpts[:, 1]
        by = bpts[:, 0]
        dists = np.sqrt((bx - cx) ** 2 + (by - cy) ** 2) / np.sqrt(area)
        radial = _stats(dists)
    else:
        radial = np.zeros(9)

    dt = distance_transform_edt(mask)
    dt_values = dt[mask] / np.sqrt(area)
    thickness = _stats(dt_values)

    return np.concatenate([
        np.array([extent, solidity, compactness, perimeter_norm, eccentricity, np.sqrt(area)]),
        hu,
        radial,
        thickness,
    ])


def extract_image_features(ids):
    features = []
    image_dir = os.path.join("input", "images")
    for img_id in ids:
        try:
            path = os.path.join(image_dir, f"{int(img_id)}.jpg")
            with Image.open(path) as img:
                arr = np.array(img.convert("L"), dtype=np.uint8)

            border = np.concatenate([arr[0, :], arr[-1, :], arr[:, 0], arr[:, -1]])
            if border.mean() >= 128:
                mask = arr < 128
            else:
                mask = arr >= 128

            feats = _image_features(mask)
        except Exception:
            feats = np.zeros(N_IMG_FEATURES)

        features.append(feats)

    return np.vstack(features).astype(np.float64)


def safe_probs(p):
    p = np.clip(p, 1e-15, 1.0)
    return p / p.sum(axis=1, keepdims=True)


def oof_probabilities(estimator, X, y, n_splits=5, random_state=42):
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=random_state)
    proba = np.zeros((X.shape[0], len(np.unique(y))))
    for train_idx, val_idx in skf.split(X, y):
        est = clone(estimator)
        est.fit(X[train_idx], y[train_idx])
        proba[val_idx] = safe_probs(est.predict_proba(X[val_idx]))
    return proba


# ----------------------------------------------------------------------
# Load data
# ----------------------------------------------------------------------
train = pd.read_csv(os.path.join("input", "train.csv"))
test = pd.read_csv(os.path.join("input", "predict.csv"))

feature_cols = [c for c in train.columns if c not in ("id", "species")]
X = train[feature_cols].values
y = train["species"].astype(str).str.strip().map(species_to_idx).values.astype(int)
ids = train["id"].values
idx = np.arange(len(train))

X_test = test[feature_cols].values
test_ids = test["id"].values

# ----------------------------------------------------------------------
# Validation split
# ----------------------------------------------------------------------
Xtr, Xval, ytr, yval, id_tr, id_val, idx_tr, idx_val = train_test_split(
    X, y, ids, idx, test_size=0.2, random_state=42, stratify=y
)

print("Extracting image features...")
img_all = extract_image_features(ids)
img_tr = img_all[idx_tr]
img_val = img_all[idx_val]
img_test = extract_image_features(test_ids)

# ----------------------------------------------------------------------
# Base models
# ----------------------------------------------------------------------
lda = LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto")
lr = Pipeline([
    ("scaler", StandardScaler()),
    ("clf", LogisticRegression(max_iter=2000, C=1.0)),
])
knn = Pipeline([
    ("scaler", StandardScaler()),
    ("clf", KNeighborsClassifier(n_neighbors=7, weights="distance")),
])
svm = Pipeline([
    ("scaler", StandardScaler()),
    ("clf", SVC(C=1.0, gamma="scale", probability=True, random_state=42)),
])

# ----------------------------------------------------------------------
# Fit stacked calibration on out-of-fold probabilities
# ----------------------------------------------------------------------
print("Computing out-of-fold probabilities for the validation split...")
lda_oof = oof_probabilities(lda, Xtr, ytr)
lr_oof = oof_probabilities(lr, Xtr, ytr)
knn_oof = oof_probabilities(knn, Xtr, ytr)
svm_oof = oof_probabilities(svm, Xtr, ytr)
print(f"  OOF LDA log loss: {log_loss(ytr, lda_oof):.6f}")
print(f"  OOF LR log loss:  {log_loss(ytr, lr_oof):.6f}")
print(f"  OOF KNN log loss: {log_loss(ytr, knn_oof):.6f}")
print(f"  OOF SVM log loss: {log_loss(ytr, svm_oof):.6f}")

stack_train = np.hstack([lda_oof, lr_oof, knn_oof, svm_oof, img_tr])

meta = Pipeline([
    ("scaler", StandardScaler()),
    ("clf", LogisticRegression(C=0.1, max_iter=2000)),
])
meta.fit(stack_train, ytr)

# ----------------------------------------------------------------------
# Honest validation score
# ----------------------------------------------------------------------
lda_val = clone(lda).fit(Xtr, ytr)
lr_val = clone(lr).fit(Xtr, ytr)
knn_val = clone(knn).fit(Xtr, ytr)
svm_val = clone(svm).fit(Xtr, ytr)

val_lda = safe_probs(lda_val.predict_proba(Xval))
val_lr = safe_probs(lr_val.predict_proba(Xval))
val_knn = safe_probs(knn_val.predict_proba(Xval))
val_svm = safe_probs(svm_val.predict_proba(Xval))

stack_val = np.hstack([val_lda, val_lr, val_knn, val_svm, img_val])
val_probs = safe_probs(meta.predict_proba(stack_val))
cal_loss = log_loss(yval, val_probs)
print(f"Stacked validation log loss: {cal_loss:.6f}")

# ----------------------------------------------------------------------
# Refit stack on full training data and predict test
# ----------------------------------------------------------------------
print("Fitting full-data stack for test predictions...")
lda_oof_full = oof_probabilities(lda, X, y)
lr_oof_full = oof_probabilities(lr, X, y)
knn_oof_full = oof_probabilities(knn, X, y)
svm_oof_full = oof_probabilities(svm, X, y)

stack_full = np.hstack([lda_oof_full, lr_oof_full, knn_oof_full, svm_oof_full, img_all])

meta_full = clone(meta)
meta_full.fit(stack_full, y)

lda_full = clone(lda).fit(X, y)
lr_full = clone(lr).fit(X, y)
knn_full = clone(knn).fit(X, y)
svm_full = clone(svm).fit(X, y)

test_lda = safe_probs(lda_full.predict_proba(X_test))
test_lr = safe_probs(lr_full.predict_proba(X_test))
test_knn = safe_probs(knn_full.predict_proba(X_test))
test_svm = safe_probs(svm_full.predict_proba(X_test))

test_stack = np.hstack([test_lda, test_lr, test_knn, test_svm, img_test])
test_probs = safe_probs(meta_full.predict_proba(test_stack))

# ----------------------------------------------------------------------
# Write submission and validation score
# ----------------------------------------------------------------------
os.makedirs(OUTPUT_DIR, exist_ok=True)

submission = pd.DataFrame({"id": test_ids})
for i, species in enumerate(SPECIES):
    submission[species] = test_probs[:, i]

submission.to_csv(os.path.join(OUTPUT_DIR, "predictions.csv"), index=False)

with open(os.path.join(OUTPUT_DIR, "val_score.json"), "w") as f:
    json.dump({"val_score": float(cal_loss)}, f)

print("Done.")
