import os
import json
import re

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss
from sklearn.model_selection import GridSearchCV, StratifiedKFold, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

if "OUTPUT_DIR" not in globals():
    OUTPUT_DIR = os.environ.get("OUTPUT_DIR", ".")
os.makedirs(OUTPUT_DIR, exist_ok=True)


def get_feature_columns(df):
    cols = []
    for prefix in ("margin", "shape", "texture"):
        matched = [
            c for c in df.columns
            if re.fullmatch(re.escape(prefix) + r"_?\d+", c)
        ]
        matched.sort(key=lambda c: int(re.search(r"\d+$", c).group(0)))
        cols.extend(matched)
    return cols


train = pd.read_csv("input/train.csv")
predict = pd.read_csv("input/predict.csv")

feature_cols = get_feature_columns(train)
if len(feature_cols) != 192:
    feature_cols = [f"{p}{i}" for p in ("margin", "shape", "texture") for i in range(1, 65)]

train["species"] = train["species"].astype(str).str.strip()
species_list = sorted(train["species"].unique())
assert len(species_list) == 99, f"Expected 99 species, got {len(species_list)}"
species_to_idx = {s: i for i, s in enumerate(species_list)}

X = train[feature_cols].to_numpy(dtype=np.float64)
y = train["species"].map(species_to_idx).to_numpy(dtype=np.int64)
X_test = predict[feature_cols].to_numpy(dtype=np.float64)

X_train, X_val, y_train, y_val = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

pipeline = Pipeline([
    ("scale", StandardScaler()),
    ("lr", LogisticRegression(solver="lbfgs", max_iter=1000, tol=1e-4)),
])

param_grid = {"lr__C": [0.01, 0.03, 0.1, 0.3, 1.0, 3.0, 10.0, 30.0]}
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

grid = GridSearchCV(
    pipeline,
    param_grid,
    scoring="neg_log_loss",
    cv=cv,
    n_jobs=1,
    refit=True,
)

grid.fit(X_train, y_train)
best_model = grid.best_estimator_

n_classes = len(species_list)
val_proba = best_model.predict_proba(X_val)
val_score = log_loss(y_val, val_proba, labels=np.arange(n_classes))
print(f"Validation log loss: {val_score:.6f}")
print(f"Best C: {grid.best_params_['lr__C']}")

best_model.fit(X, y)
test_proba = best_model.predict_proba(X_test)
test_proba = test_proba / test_proba.sum(axis=1, keepdims=True)

submission = pd.DataFrame(test_proba, columns=species_list)
submission.insert(0, "id", predict["id"].values)
submission.to_csv(os.path.join(OUTPUT_DIR, "predictions.csv"), index=False)

with open(os.path.join(OUTPUT_DIR, "val_score.json"), "w") as f:
    json.dump({"val_score": float(val_score)}, f)
