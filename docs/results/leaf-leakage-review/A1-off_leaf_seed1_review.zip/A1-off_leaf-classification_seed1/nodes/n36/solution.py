import os
import json
import warnings

import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.metrics import log_loss
from sklearn.base import clone
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC

warnings.filterwarnings("ignore")

try:
    OUTPUT_DIR
except NameError:
    OUTPUT_DIR = "."

SPECIES = [
    "Acer_Capillipes", "Acer_Circinatum", "Acer_Mono", "Acer_Opalus",
    "Acer_Palmatum", "Acer_Pictum", "Acer_Platanoids", "Acer_Rubrum",
    "Acer_Rufinerve", "Acer_Saccharinum", "Alnus_Cordata", "Alnus_Maximowiczii",
    "Alnus_Rubra", "Alnus_Sieboldiana", "Alnus_Viridis", "Arundinaria_Simonii",
    "Betula_Austrosinensis", "Betula_Pendula", "Callicarpa_Bodinieri",
    "Castanea_Sativa", "Celtis_Koraiensis", "Cercis_Siliquastrum",
    "Cornus_Chinensis", "Cornus_Controversa", "Cornus_Macrophylla",
    "Cotinus_Coggygria", "Crataegus_Monogyna", "Cytisus_Battandieri",
    "Eucalyptus_Glaucescens", "Eucalyptus_Neglecta", "Eucalyptus_Urnigera",
    "Fagus_Sylvatica", "Ginkgo_Biloba", "Ilex_Aquifolium", "Ilex_Cornuta",
    "Liquidambar_Styraciflua", "Liriodendron_Tulipifera",
    "Lithocarpus_Cleistocarpus", "Lithocarpus_Edulis", "Magnolia_Heptapeta",
    "Magnolia_Salicifolia", "Morus_Nigra", "Olea_Europaea", "Phildelphus",
    "Populus_Adenopoda", "Populus_Grandidentata", "Populus_Nigra",
    "Prunus_Avium", "Prunus_X_Shmittii", "Pterocarya_Stenoptera",
    "Quercus_Afares", "Quercus_Agrifolia", "Quercus_Alnifolia",
    "Quercus_Brantii", "Quercus_Canariensis", "Quercus_Castaneifolia",
    "Quercus_Cerris", "Quercus_Chrysolepis", "Quercus_Coccifera",
    "Quercus_Coccinea", "Quercus_Crassifolia", "Quercus_Crassipes",
    "Quercus_Dolicholepis", "Quercus_Ellipsoidalis", "Quercus_Greggii",
    "Quercus_Hartwissiana", "Quercus_Ilex", "Quercus_Imbricaria",
    "Quercus_Infectoria_sub", "Quercus_Kewensis", "Quercus_Nigra",
    "Quercus_Palustris", "Quercus_Phellos", "Quercus_Phillyraeoides",
    "Quercus_Pontica", "Quercus_Pubescens", "Quercus_Pyrenaica",
    "Quercus_Rhysophylla", "Quercus_Rubra", "Quercus_Semecarpifolia",
    "Quercus_Shumardii", "Quercus_Suber", "Quercus_Texana",
    "Quercus_Trojana", "Quercus_Variabilis", "Quercus_Vulcanica",
    "Quercus_x_Hispanica", "Quercus_x_Turneri", "Rhododendron_x_Russellianum",
    "Salix_Fragilis", "Salix_Intergra", "Sorbus_Aria", "Tilia_Oliveri",
    "Tilia_Platyphyllos", "Tilia_Tomentosa", "Ulmus_Bergmanniana",
    "Viburnum_Tinus", "Viburnum_x_Rhytidophylloides", "Zelkova_Serrata",
]

species_to_idx = {name: i for i, name in enumerate(SPECIES)}

# ---------------------------------------------------------------
# Load data
# ---------------------------------------------------------------
train = pd.read_csv(os.path.join("input", "train.csv"))
test = pd.read_csv(os.path.join("input", "predict.csv"))

feature_cols = [c for c in train.columns if c not in ("id", "species")]
X = train[feature_cols].values
y = train["species"].astype(str).map(species_to_idx).values.astype(int)

X_test = test[feature_cols].values
test_ids = test["id"].values

# ---------------------------------------------------------------
# Validation split
# ---------------------------------------------------------------
Xtr, Xval, ytr, yval = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# ---------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------
def safe_probs(p):
    p = np.clip(p, 1e-15, 1.0)
    return p / p.sum(axis=1, keepdims=True)


def log_probs(p):
    return np.log(np.clip(p, 1e-15, 1.0))


def oof_probabilities(estimator, X, y, n_splits=5, random_state=42):
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=random_state)
    proba = np.zeros((X.shape[0], len(np.unique(y))))
    for train_idx, val_idx in skf.split(X, y):
        est = clone(estimator)
        est.fit(X[train_idx], y[train_idx])
        p = est.predict_proba(X[val_idx])
        proba[val_idx] = safe_probs(p)
    return proba


# ---------------------------------------------------------------
# Base models
# ---------------------------------------------------------------
lda = LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto")
lr = Pipeline([
    ("scaler", StandardScaler()),
    ("clf", LogisticRegression(max_iter=2000, C=1.0)),
])
knn = Pipeline([
    ("scaler", StandardScaler()),
    ("clf", KNeighborsClassifier(n_neighbors=7, weights="distance")),
])
svm = Pipeline([
    ("scaler", StandardScaler()),
    ("clf", SVC(C=1.0, gamma="scale", probability=True, random_state=42)),
])

# ---------------------------------------------------------------
# Fit stacked calibration on out-of-fold probabilities
# ---------------------------------------------------------------
print("Computing out-of-fold probabilities for the validation split...")
lda_oof = oof_probabilities(lda, Xtr, ytr)
lr_oof = oof_probabilities(lr, Xtr, ytr)
knn_oof = oof_probabilities(knn, Xtr, ytr)
svm_oof = oof_probabilities(svm, Xtr, ytr)
print(f"  OOF LDA log loss: {log_loss(ytr, lda_oof):.6f}")
print(f"  OOF LR log loss:  {log_loss(ytr, lr_oof):.6f}")
print(f"  OOF KNN log loss: {log_loss(ytr, knn_oof):.6f}")
print(f"  OOF SVM log loss: {log_loss(ytr, svm_oof):.6f}")

# Stack log-probabilities instead of raw probabilities
stack_train = np.hstack([log_probs(lda_oof), log_probs(lr_oof), log_probs(knn_oof), log_probs(svm_oof)])

meta = Pipeline([
    ("scaler", StandardScaler()),
    ("clf", LogisticRegression(C=0.1, max_iter=2000)),
])
meta.fit(stack_train, ytr)

# ---------------------------------------------------------------
# Honest validation score: stack trained only on the training split
# ---------------------------------------------------------------
val_lda = safe_probs(clone(lda).fit(Xtr, ytr).predict_proba(Xval))
val_lr = safe_probs(clone(lr).fit(Xtr, ytr).predict_proba(Xval))
val_knn = safe_probs(clone(knn).fit(Xtr, ytr).predict_proba(Xval))
val_svm = safe_probs(clone(svm).fit(Xtr, ytr).predict_proba(Xval))
stack_val = np.hstack([log_probs(val_lda), log_probs(val_lr), log_probs(val_knn), log_probs(val_svm)])
val_probs = safe_probs(meta.predict_proba(stack_val))
cal_loss = log_loss(yval, val_probs)
print(f"Stacked validation log loss: {cal_loss:.6f}")

# ---------------------------------------------------------------
# Refit stack on full training data and predict test
# ---------------------------------------------------------------
print("Fitting full-data stack for test predictions...")
lda_oof_full = oof_probabilities(lda, X, y)
lr_oof_full = oof_probabilities(lr, X, y)
knn_oof_full = oof_probabilities(knn, X, y)
svm_oof_full = oof_probabilities(svm, X, y)
stack_full = np.hstack([log_probs(lda_oof_full), log_probs(lr_oof_full), log_probs(knn_oof_full), log_probs(svm_oof_full)])

meta_full = clone(meta)
meta_full.fit(stack_full, y)

lda_full = clone(lda).fit(X, y)
lr_full = clone(lr).fit(X, y)
knn_full = clone(knn).fit(X, y)
svm_full = clone(svm).fit(X, y)

test_lda = safe_probs(lda_full.predict_proba(X_test))
test_lr = safe_probs(lr_full.predict_proba(X_test))
test_knn = safe_probs(knn_full.predict_proba(X_test))
test_svm = safe_probs(svm_full.predict_proba(X_test))
test_probs = safe_probs(meta_full.predict_proba(np.hstack([log_probs(test_lda), log_probs(test_lr), log_probs(test_knn), log_probs(test_svm)])))

# ---------------------------------------------------------------
# Write submission
# ---------------------------------------------------------------
submission = pd.DataFrame({"id": test_ids})
for i, species in enumerate(SPECIES):
    submission[species] = test_probs[:, i]

submission.to_csv(os.path.join(OUTPUT_DIR, "predictions.csv"), index=False)

with open(os.path.join(OUTPUT_DIR, "val_score.json"), "w") as f:
    json.dump({"val_score": float(cal_loss)}, f)

print("Done.")
