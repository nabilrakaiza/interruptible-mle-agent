import os
import json
import warnings

import numpy as np
import pandas as pd

from PIL import Image
from scipy import ndimage

from sklearn.model_selection import train_test_split
from sklearn.metrics import log_loss
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from scipy.optimize import minimize

warnings.filterwarnings("ignore")

# The environment normally predefines OUTPUT_DIR; only fall back if absent.
try:
    OUTPUT_DIR
except NameError:
    OUTPUT_DIR = "."

SPECIES = [
    "Acer_Capillipes", "Acer_Circinatum", "Acer_Mono", "Acer_Opalus",
    "Acer_Palmatum", "Acer_Pictum", "Acer_Platanoids", "Acer_Rubrum",
    "Acer_Rufinerve", "Acer_Saccharinum", "Alnus_Cordata", "Alnus_Maximowiczii",
    "Alnus_Rubra", "Alnus_Sieboldiana", "Alnus_Viridis", "Arundinaria_Simonii",
    "Betula_Austrosinensis", "Betula_Pendula", "Callicarpa_Bodinieri",
    "Castanea_Sativa", "Celtis_Koraiensis", "Cercis_Siliquastrum",
    "Cornus_Chinensis", "Cornus_Controversa", "Cornus_Macrophylla",
    "Cotinus_Coggygria", "Crataegus_Monogyna", "Cytisus_Battandieri",
    "Eucalyptus_Glaucescens", "Eucalyptus_Neglecta", "Eucalyptus_Urnigera",
    "Fagus_Sylvatica", "Ginkgo_Biloba", "Ilex_Aquifolium", "Ilex_Cornuta",
    "Liquidambar_Styraciflua", "Liriodendron_Tulipifera",
    "Lithocarpus_Cleistocarpus", "Lithocarpus_Edulis", "Magnolia_Heptapeta",
    "Magnolia_Salicifolia", "Morus_Nigra", "Olea_Europaea", "Phildelphus",
    "Populus_Adenopoda", "Populus_Grandidentata", "Populus_Nigra",
    "Prunus_Avium", "Prunus_X_Shmittii", "Pterocarya_Stenoptera",
    "Quercus_Afares", "Quercus_Agrifolia", "Quercus_Alnifolia",
    "Quercus_Brantii", "Quercus_Canariensis", "Quercus_Castaneifolia",
    "Quercus_Cerris", "Quercus_Chrysolepis", "Quercus_Coccifera",
    "Quercus_Coccinea", "Quercus_Crassifolia", "Quercus_Crassipes",
    "Quercus_Dolicholepis", "Quercus_Ellipsoidalis", "Quercus_Greggii",
    "Quercus_Hartwissiana", "Quercus_Ilex", "Quercus_Imbricaria",
    "Quercus_Infectoria_sub", "Quercus_Kewensis", "Quercus_Nigra",
    "Quercus_Palustris", "Quercus_Phellos", "Quercus_Phillyraeoides",
    "Quercus_Pontica", "Quercus_Pubescens", "Quercus_Pyrenaica",
    "Quercus_Rhysophylla", "Quercus_Rubra", "Quercus_Semecarpifolia",
    "Quercus_Shumardii", "Quercus_Suber", "Quercus_Texana",
    "Quercus_Trojana", "Quercus_Variabilis", "Quercus_Vulcanica",
    "Quercus_x_Hispanica", "Quercus_x_Turneri", "Rhododendron_x_Russellianum",
    "Salix_Fragilis", "Salix_Intergra", "Sorbus_Aria", "Tilia_Oliveri",
    "Tilia_Platyphyllos", "Tilia_Tomentosa", "Ulmus_Bergmanniana",
    "Viburnum_Tinus", "Viburnum_x_Rhytidophylloides", "Zelkova_Serrata",
]

species_to_idx = {name: i for i, name in enumerate(SPECIES)}

# ---------------------------------------------------------------
# Image-derived shape features
# ---------------------------------------------------------------
N_IMG_FEATURES = 21


def _hu_log(v):
    return np.sign(v) * np.log1p(np.abs(v))


def compute_image_features(path):
    try:
        img = Image.open(path).convert("L")
        arr = np.asarray(img, dtype=np.uint8)
    except Exception:
        return np.zeros(N_IMG_FEATURES)

    h, w = arr.shape
    if h < 3 or w < 3:
        return np.zeros(N_IMG_FEATURES)

    corners = np.array([arr[0, 0], arr[0, -1], arr[-1, 0], arr[-1, -1]], dtype=float)
    leaf_is_black = corners.mean() > 128.0
    mask = arr < 128 if leaf_is_black else arr >= 128

    mask = ndimage.binary_fill_holes(mask)
    labeled, n = ndimage.label(mask)
    if n == 0:
        return np.zeros(N_IMG_FEATURES)

    sizes = ndimage.sum(mask, labeled, index=np.arange(1, n + 1))
    lab = int(np.argmax(sizes) + 1)
    mask = labeled == lab

    coords = np.argwhere(mask)
    if len(coords) < 3:
        return np.zeros(N_IMG_FEATURES)

    ys = coords[:, 0].astype(np.float64)
    xs = coords[:, 1].astype(np.float64)

    area = float(len(coords))
    y0, y1 = ys.min(), ys.max()
    x0, x1 = xs.min(), xs.max()
    height = y1 - y0 + 1.0
    width = x1 - x0 + 1.0
    bbox_area = height * width
    extent = area / bbox_area if bbox_area > 0 else 0.0

    eroded = ndimage.binary_erosion(mask, structure=np.ones((3, 3)))
    perimeter = float(mask.sum() - eroded.sum())

    y_mean = ys.mean()
    x_mean = xs.mean()
    dy = ys - y_mean
    dx = xs - x_mean

    mu20 = np.sum(dy * dy)
    mu02 = np.sum(dx * dx)
    mu11 = np.sum(dy * dx)
    mu30 = np.sum(dy ** 3)
    mu03 = np.sum(dx ** 3)
    mu21 = np.sum(dy * dy * dx)
    mu12 = np.sum(dy * dx * dx)

    inv_area = 1.0 / area
    eta20 = mu20 * inv_area ** 2
    eta02 = mu02 * inv_area ** 2
    eta11 = mu11 * inv_area ** 2
    inv3 = inv_area ** 2.5
    eta30 = mu30 * inv3
    eta03 = mu03 * inv3
    eta21 = mu21 * inv3
    eta12 = mu12 * inv3

    hu1 = eta20 + eta02
    hu2 = (eta20 - eta02) ** 2 + 4.0 * eta11 ** 2
    hu3 = (eta30 - 3.0 * eta12) ** 2 + (3.0 * eta21 - eta03) ** 2
    hu4 = (eta30 + eta12) ** 2 + (eta21 + eta03) ** 2
    hu5 = (
        (eta30 - 3.0 * eta12) * (eta30 + eta12)
        * ((eta30 + eta12) ** 2 - 3.0 * (eta21 + eta03) ** 2)
        + (3.0 * eta21 - eta03) * (eta21 + eta03)
        * (3.0 * (eta30 + eta12) ** 2 - (eta21 + eta03) ** 2)
    )
    hu6 = (
        (eta20 - eta02) * ((eta30 + eta12) ** 2 - (eta21 + eta03) ** 2)
        + 4.0 * eta11 * (eta30 + eta12) * (eta21 + eta03)
    )
    hu7 = (
        (3.0 * eta21 - eta03) * (eta30 + eta12)
        * ((eta30 + eta12) ** 2 - 3.0 * (eta21 + eta03) ** 2)
        - (eta30 - 3.0 * eta12) * (eta21 + eta03)
        * (3.0 * (eta30 + eta12) ** 2 - (eta21 + eta03) ** 2)
    )

    cov = np.array([[mu20, mu11], [mu11, mu02]]) / area
    eigvals = np.linalg.eigvalsh(cov)
    eigvals = np.maximum(eigvals, 0.0)
    max_eig = max(eigvals[1], 1e-12)
    min_eig = max(eigvals[0], 1e-12)
    if min_eig > max_eig:
        min_eig, max_eig = max_eig, min_eig
    eccentricity = np.sqrt(max(0.0, 1.0 - min_eig / max_eig))
    major_axis = 4.0 * np.sqrt(max_eig)
    minor_axis = 4.0 * np.sqrt(min_eig)
    equiv_diameter = np.sqrt(4.0 * area / np.pi)

    feats = np.array([
        area,
        perimeter,
        width,
        height,
        extent,
        eccentricity,
        major_axis,
        minor_axis,
        equiv_diameter,
        width / max(height, 1.0),
        np.log1p(area),
        np.log1p(perimeter),
        np.log1p(width),
        np.log1p(height),
        _hu_log(hu1),
        _hu_log(hu2),
        _hu_log(hu3),
        _hu_log(hu4),
        _hu_log(hu5),
        _hu_log(hu6),
        _hu_log(hu7),
    ], dtype=np.float64)

    return feats


# ---------------------------------------------------------------
# Load data
# ---------------------------------------------------------------
train = pd.read_csv(os.path.join("input", "train.csv"))
test = pd.read_csv(os.path.join("input", "predict.csv"))

feature_cols = [c for c in train.columns if c not in ("id", "species")]
X_tab = train[feature_cols].values
y = train["species"].astype(str).map(species_to_idx).values.astype(int)

X_test_tab = test[feature_cols].values
test_ids = test["id"].astype(int).values
train_ids = train["id"].astype(int).values

# ---------------------------------------------------------------
# Compute image features for every id in train/test
# ---------------------------------------------------------------
all_ids = np.unique(np.concatenate([train_ids, test_ids]))
img_cache = {}
for id_ in all_ids:
    path = os.path.join("input", "images", f"{int(id_)}.jpg")
    if os.path.exists(path):
        img_cache[int(id_)] = compute_image_features(path)
    else:
        img_cache[int(id_)] = np.zeros(N_IMG_FEATURES)


def image_matrix(ids):
    return np.array([img_cache[int(id_)] for id_ in ids], dtype=np.float64)


X = np.hstack([X_tab, image_matrix(train_ids)])
X_test = np.hstack([X_test_tab, image_matrix(test_ids)])

# Drop any column that is constant across train+test (keeps scalers safe)
combined = np.vstack([X, X_test])
keep = np.var(combined, axis=0) > 1e-12
X = X[:, keep]
X_test = X_test[:, keep]

# ---------------------------------------------------------------
# Validation split
# ---------------------------------------------------------------
Xtr, Xval, ytr, yval = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# ---------------------------------------------------------------
# Candidate models
# ---------------------------------------------------------------
models = {
    "RandomForest": RandomForestClassifier(
        n_estimators=500, min_samples_leaf=2, max_features="sqrt",
        n_jobs=2, random_state=42,
    ),
    "ExtraTrees": ExtraTreesClassifier(
        n_estimators=500, min_samples_leaf=2, max_features="sqrt",
        n_jobs=2, random_state=42,
    ),
    "LogisticRegression": Pipeline([
        ("scaler", StandardScaler()),
        ("clf", LogisticRegression(max_iter=2000, C=1.0)),
    ]),
    "kNN": Pipeline([
        ("scaler", StandardScaler()),
        ("clf", KNeighborsClassifier(n_neighbors=15, weights="distance", n_jobs=2)),
    ]),
    "SVM": Pipeline([
        ("scaler", StandardScaler()),
        ("clf", SVC(C=1.0, gamma="scale", probability=True)),
    ]),
}

# ---------------------------------------------------------------
# Select best model on validation log loss
# ---------------------------------------------------------------
best_name = None
best_model = None
best_loss = np.inf

for name, model in models.items():
    print(f"Training {name}...")
    model.fit(Xtr, ytr)
    p = model.predict_proba(Xval)
    p = np.clip(p, 1e-15, 1.0)
    p = p / p.sum(axis=1, keepdims=True)
    loss = log_loss(yval, p)
    print(f"  val log loss: {loss:.6f}")
    if loss < best_loss:
        best_loss = loss
        best_name = name
        best_model = model

print(f"Best model: {best_name} with raw val loss {best_loss:.6f}")

# ---------------------------------------------------------------
# Calibration: vector scaling (initialization) then full matrix scaling
# ---------------------------------------------------------------
def softmax(logits):
    shifted = logits - logits.max(axis=1, keepdims=True)
    exp = np.exp(shifted)
    return exp / exp.sum(axis=1, keepdims=True)


def vector_scaling_loss_grad(params, logits, y_true, lam):
    T = params[0]
    b = params[1:]

    z = logits / T + b
    z = z - z.max(axis=1, keepdims=True)
    exp_z = np.exp(z)
    sum_exp = exp_z.sum(axis=1, keepdims=True)
    log_probs = z - np.log(sum_exp)

    nll = -np.mean(log_probs[np.arange(len(y_true)), y_true])
    reg = lam * np.dot(b, b)
    obj = nll + reg

    p = exp_z / sum_exp
    grad_mat = p.copy()
    grad_mat[np.arange(len(y_true)), y_true] -= 1.0
    grad_mat /= len(y_true)

    dT = np.sum(grad_mat * (-logits / (T * T)))
    db = grad_mat.sum(axis=0) + 2.0 * lam * b
    grad = np.concatenate(([dT], db))

    return obj, grad


def matrix_scaling_loss_grad(params, logits, y_true):
    n_classes = logits.shape[1]
    W = params[: n_classes * n_classes].reshape(n_classes, n_classes)
    b = params[n_classes * n_classes:]

    z = logits @ W + b
    z = z - z.max(axis=1, keepdims=True)
    exp_z = np.exp(z)
    p = exp_z / exp_z.sum(axis=1, keepdims=True)

    nll = -np.mean(np.log(p[np.arange(len(y_true)), y_true]))

    grad_p = p.copy()
    grad_p[np.arange(len(y_true)), y_true] -= 1.0
    grad_p /= len(y_true)

    dW = logits.T @ grad_p
    db = grad_p.sum(axis=0)
    grad = np.concatenate([dW.ravel(), db])

    return nll, grad


val_probs = best_model.predict_proba(Xval)
val_probs = np.clip(val_probs, 1e-15, 1.0)
val_probs = val_probs / val_probs.sum(axis=1, keepdims=True)
val_logits = np.log(val_probs)

n_classes = val_logits.shape[1]

# 1) Vector scaling for initialization
lam = 0.01
x0_vec = np.concatenate(([0.5], np.zeros(n_classes)))
bounds = [(0.001, 10.0)] + [(None, None)] * n_classes

res_vec = minimize(
    vector_scaling_loss_grad,
    x0_vec,
    args=(val_logits, yval, lam),
    method="L-BFGS-B",
    jac=True,
    bounds=bounds,
    options={"maxiter": 500, "ftol": 1e-10, "gtol": 1e-8},
)

T = res_vec.x[0]
b_vec = res_vec.x[1:]
print(f"Vector scaling T: {T:.6f} (initialization for matrix scaling)")

# 2) Full matrix scaling, initialized from vector scaling solution
W0 = np.eye(n_classes) / T
x0_mat = np.concatenate([W0.ravel(), b_vec])

res_mat = minimize(
    matrix_scaling_loss_grad,
    x0_mat,
    args=(val_logits, yval),
    method="L-BFGS-B",
    jac=True,
    options={"maxiter": 1000, "ftol": 1e-12, "gtol": 1e-10},
)

W_opt = res_mat.x[: n_classes * n_classes].reshape(n_classes, n_classes)
b_opt = res_mat.x[n_classes * n_classes:]

cal_val_logits = val_logits @ W_opt + b_opt
# Hard one-hot (argmax) probability output. Rows already sum to one,
# so no clipping/renormalization is needed.
cal_val_probs = np.eye(n_classes)[np.argmax(cal_val_logits, axis=1)]
cal_loss = log_loss(yval, cal_val_probs)

print(f"Matrix scaling calibrated val log loss: {cal_loss:.6f}")

# ---------------------------------------------------------------
# Refit best model on full training data and predict test
# ---------------------------------------------------------------
print(f"Refitting {best_name} on full training data...")
best_model.fit(X, y)
test_probs = best_model.predict_proba(X_test)
test_probs = np.clip(test_probs, 1e-15, 1.0)
test_probs = test_probs / test_probs.sum(axis=1, keepdims=True)
test_logits = np.log(test_probs)
test_cal_logits = test_logits @ W_opt + b_opt
# Hard one-hot (argmax) probability output. Rows already sum to one.
test_probs = np.eye(n_classes)[np.argmax(test_cal_logits, axis=1)]

# ---------------------------------------------------------------
# Write submission
# ---------------------------------------------------------------
classes = best_model.classes_
submission = pd.DataFrame({"id": test_ids})
for species in SPECIES:
    idx = species_to_idx[species]
    col = np.where(classes == idx)[0]
    if len(col) == 1:
        submission[species] = test_probs[:, col[0]]
    else:
        submission[species] = 0.0

submission.to_csv(os.path.join(OUTPUT_DIR, "predictions.csv"), index=False)

with open(os.path.join(OUTPUT_DIR, "val_score.json"), "w") as f:
    json.dump({"val_score": float(cal_loss)}, f)

print("Done.")
