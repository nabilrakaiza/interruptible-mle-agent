import os
import json
import warnings

import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.metrics import log_loss
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from scipy.optimize import minimize_scalar

warnings.filterwarnings("ignore")

try:
    OUTPUT_DIR
except NameError:
    OUTPUT_DIR = "."

SPECIES = [
    "Acer_Capillipes", "Acer_Circinatum", "Acer_Mono", "Acer_Opalus",
    "Acer_Palmatum", "Acer_Pictum", "Acer_Platanoids", "Acer_Rubrum",
    "Acer_Rufinerve", "Acer_Saccharinum", "Alnus_Cordata", "Alnus_Maximowiczii",
    "Alnus_Rubra", "Alnus_Sieboldiana", "Alnus_Viridis", "Arundinaria_Simonii",
    "Betula_Austrosinensis", "Betula_Pendula", "Callicarpa_Bodinieri",
    "Castanea_Sativa", "Celtis_Koraiensis", "Cercis_Siliquastrum",
    "Cornus_Chinensis", "Cornus_Controversa", "Cornus_Macrophylla",
    "Cotinus_Coggygria", "Crataegus_Monogyna", "Cytisus_Battandieri",
    "Eucalyptus_Glaucescens", "Eucalyptus_Neglecta", "Eucalyptus_Urnigera",
    "Fagus_Sylvatica", "Ginkgo_Biloba", "Ilex_Aquifolium", "Ilex_Cornuta",
    "Liquidambar_Styraciflua", "Liriodendron_Tulipifera",
    "Lithocarpus_Cleistocarpus", "Lithocarpus_Edulis", "Magnolia_Heptapeta",
    "Magnolia_Salicifolia", "Morus_Nigra", "Olea_Europaea", "Phildelphus",
    "Populus_Adenopoda", "Populus_Grandidentata", "Populus_Nigra",
    "Prunus_Avium", "Prunus_X_Shmittii", "Pterocarya_Stenoptera",
    "Quercus_Afares", "Quercus_Agrifolia", "Quercus_Alnifolia",
    "Quercus_Brantii", "Quercus_Canariensis", "Quercus_Castaneifolia",
    "Quercus_Cerris", "Quercus_Chrysolepis", "Quercus_Coccifera",
    "Quercus_Coccinea", "Quercus_Crassifolia", "Quercus_Crassipes",
    "Quercus_Dolicholepis", "Quercus_Ellipsoidalis", "Quercus_Greggii",
    "Quercus_Hartwissiana", "Quercus_Ilex", "Quercus_Imbricaria",
    "Quercus_Infectoria_sub", "Quercus_Kewensis", "Quercus_Nigra",
    "Quercus_Palustris", "Quercus_Phellos", "Quercus_Phillyraeoides",
    "Quercus_Pontica", "Quercus_Pubescens", "Quercus_Pyrenaica",
    "Quercus_Rhysophylla", "Quercus_Rubra", "Quercus_Semecarpifolia",
    "Quercus_Shumardii", "Quercus_Suber", "Quercus_Texana",
    "Quercus_Trojana", "Quercus_Variabilis", "Quercus_Vulcanica",
    "Quercus_x_Hispanica", "Quercus_x_Turneri", "Rhododendron_x_Russellianum",
    "Salix_Fragilis", "Salix_Intergra", "Sorbus_Aria", "Tilia_Oliveri",
    "Tilia_Platyphyllos", "Tilia_Tomentosa", "Ulmus_Bergmanniana",
    "Viburnum_Tinus", "Viburnum_x_Rhytidophylloides", "Zelkova_Serrata",
]

species_to_idx = {name: i for i, name in enumerate(SPECIES)}

# ----------------------------------------------------------------------
# Load data
# ----------------------------------------------------------------------
train = pd.read_csv(os.path.join("input", "train.csv"))
test = pd.read_csv(os.path.join("input", "predict.csv"))

feature_cols = [c for c in train.columns if c not in ("id", "species")]
X = train[feature_cols].values
y = train["species"].astype(str).map(species_to_idx).values.astype(int)
X_test = test[feature_cols].values
test_ids = test["id"].values

# ----------------------------------------------------------------------
# Feature views: margin / shape / texture and useful combinations
# ----------------------------------------------------------------------
margin_cols = [c for c in feature_cols if c.startswith("margin")]
shape_cols = [c for c in feature_cols if c.startswith("shape")]
texture_cols = [c for c in feature_cols if c.startswith("texture")]

views = {
    "all": feature_cols,
    "margin": margin_cols,
    "shape": shape_cols,
    "texture": texture_cols,
    "margin_shape": margin_cols + shape_cols,
    "margin_texture": margin_cols + texture_cols,
    "shape_texture": shape_cols + texture_cols,
}
view_indices = {
    name: [feature_cols.index(c) for c in cols] for name, cols in views.items()
}

# ----------------------------------------------------------------------
# Outer validation split
# ----------------------------------------------------------------------
Xtr, Xval, ytr, yval = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Inner split for honest view weighting / temperature selection
Xsub, Xcal, ysub, ycal = train_test_split(
    Xtr, ytr, test_size=0.3, random_state=42, stratify=ytr
)


def fit_lda(Xv, yv):
    return LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto").fit(Xv, yv)


def safe_probs(model, Xv):
    p = model.predict_proba(Xv)
    p = np.clip(p, 1e-15, 1.0)
    p = p / p.sum(axis=1, keepdims=True)
    return p


def softmax(z):
    z = z - z.max(axis=1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(axis=1, keepdims=True)


def combined_logprobs(probs_list, weights_list):
    logsum = np.zeros_like(probs_list[0], dtype=float)
    for p, w in zip(probs_list, weights_list):
        logsum += w * np.log(np.clip(p, 1e-15, 1.0))
    return logsum / sum(weights_list)


# ----------------------------------------------------------------------
# Evaluate each view on the inner calibration set
# ----------------------------------------------------------------------
view_losses = {}
for name, idxs in view_indices.items():
    model = fit_lda(Xsub[:, idxs], ysub)
    p = safe_probs(model, Xcal[:, idxs])
    view_losses[name] = log_loss(ycal, p)
    print(f"View {name}: inner val log loss = {view_losses[name]:.6f}")

# Inverse-log-loss weights; stable even for very small losses
weights = {
    name: 1.0 / ((loss + 1e-6) ** 2) for name, loss in view_losses.items()
}
weight_list = [weights[name] for name in views.keys()]

# ----------------------------------------------------------------------
# Fit temperature on the inner calibration set
# ----------------------------------------------------------------------
probs_cal = []
for name, idxs in view_indices.items():
    model = fit_lda(Xsub[:, idxs], ysub)
    probs_cal.append(safe_probs(model, Xcal[:, idxs]))

logits_cal = combined_logprobs(probs_cal, weight_list)


def temperature_loss(T, logits, y_true):
    return log_loss(y_true, softmax(logits / T))


res = minimize_scalar(
    temperature_loss,
    bounds=(0.05, 5.0),
    method="bounded",
    args=(logits_cal, ycal),
)
T = res.x
print(f"Temperature: {T:.6f}")

# ----------------------------------------------------------------------
# Honest outer validation score
# ----------------------------------------------------------------------
probs_val = []
for name, idxs in view_indices.items():
    model = fit_lda(Xtr[:, idxs], ytr)
    probs_val.append(safe_probs(model, Xval[:, idxs]))

logits_val = combined_logprobs(probs_val, weight_list)
val_probs = softmax(logits_val / T)
val_probs = np.clip(val_probs, 1e-15, 1.0)
val_probs = val_probs / val_probs.sum(axis=1, keepdims=True)
val_score = log_loss(yval, val_probs)
print(f"Outer validation log loss: {val_score:.6f}")

# ----------------------------------------------------------------------
# Refit on all training data and predict test
# ----------------------------------------------------------------------
probs_test = []
for name, idxs in view_indices.items():
    model = fit_lda(X[:, idxs], y)
    probs_test.append(safe_probs(model, X_test[:, idxs]))

logits_test = combined_logprobs(probs_test, weight_list)
test_probs = softmax(logits_test / T)
test_probs = np.clip(test_probs, 1e-15, 1.0)
test_probs = test_probs / test_probs.sum(axis=1, keepdims=True)

# LDA was fit on integer labels 0..98, so columns are already in SPECIES order.
submission = pd.DataFrame({"id": test_ids})
for i, species in enumerate(SPECIES):
    submission[species] = test_probs[:, i]

submission.to_csv(os.path.join(OUTPUT_DIR, "predictions.csv"), index=False)

with open(os.path.join(OUTPUT_DIR, "val_score.json"), "w") as f:
    json.dump({"val_score": float(val_score)}, f)

print("Done.")
