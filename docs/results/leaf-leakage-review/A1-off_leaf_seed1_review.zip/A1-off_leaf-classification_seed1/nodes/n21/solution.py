import os
import json
import warnings

import numpy as np
import pandas as pd

from sklearn.base import clone
from sklearn.model_selection import train_test_split
from sklearn.metrics import log_loss
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.calibration import CalibratedClassifierCV
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

warnings.filterwarnings("ignore")

try:
    OUTPUT_DIR
except NameError:
    OUTPUT_DIR = "."

SPECIES = [
    "Acer_Capillipes", "Acer_Circinatum", "Acer_Mono", "Acer_Opalus",
    "Acer_Palmatum", "Acer_Pictum", "Acer_Platanoids", "Acer_Rubrum",
    "Acer_Rufinerve", "Acer_Saccharinum", "Alnus_Cordata", "Alnus_Maximowiczii",
    "Alnus_Rubra", "Alnus_Sieboldiana", "Alnus_Viridis", "Arundinaria_Simonii",
    "Betula_Austrosinensis", "Betula_Pendula", "Callicarpa_Bodinieri",
    "Castanea_Sativa", "Celtis_Koraiensis", "Cercis_Siliquastrum",
    "Cornus_Chinensis", "Cornus_Controversa", "Cornus_Macrophylla",
    "Cotinus_Coggygria", "Crataegus_Monogyna", "Cytisus_Battandieri",
    "Eucalyptus_Glaucescens", "Eucalyptus_Neglecta", "Eucalyptus_Urnigera",
    "Fagus_Sylvatica", "Ginkgo_Biloba", "Ilex_Aquifolium", "Ilex_Cornuta",
    "Liquidambar_Styraciflua", "Liriodendron_Tulipifera",
    "Lithocarpus_Cleistocarpus", "Lithocarpus_Edulis", "Magnolia_Heptapeta",
    "Magnolia_Salicifolia", "Morus_Nigra", "Olea_Europaea", "Phildelphus",
    "Populus_Adenopoda", "Populus_Grandidentata", "Populus_Nigra",
    "Prunus_Avium", "Prunus_X_Shmittii", "Pterocarya_Stenoptera",
    "Quercus_Afares", "Quercus_Agrifolia", "Quercus_Alnifolia",
    "Quercus_Brantii", "Quercus_Canariensis", "Quercus_Castaneifolia",
    "Quercus_Cerris", "Quercus_Chrysolepis", "Quercus_Coccifera",
    "Quercus_Coccinea", "Quercus_Crassifolia", "Quercus_Crassipes",
    "Quercus_Dolicholepis", "Quercus_Ellipsoidalis", "Quercus_Greggii",
    "Quercus_Hartwissiana", "Quercus_Ilex", "Quercus_Imbricaria",
    "Quercus_Infectoria_sub", "Quercus_Kewensis", "Quercus_Nigra",
    "Quercus_Palustris", "Quercus_Phellos", "Quercus_Phillyraeoides",
    "Quercus_Pontica", "Quercus_Pubescens", "Quercus_Pyrenaica",
    "Quercus_Rhysophylla", "Quercus_Rubra", "Quercus_Semecarpifolia",
    "Quercus_Shumardii", "Quercus_Suber", "Quercus_Texana",
    "Quercus_Trojana", "Quercus_Variabilis", "Quercus_Vulcanica",
    "Quercus_x_Hispanica", "Quercus_x_Turneri", "Rhododendron_x_Russellianum",
    "Salix_Fragilis", "Salix_Intergra", "Sorbus_Aria", "Tilia_Oliveri",
    "Tilia_Platyphyllos", "Tilia_Tomentosa", "Ulmus_Bergmanniana",
    "Viburnum_Tinus", "Viburnum_x_Rhytidophylloides", "Zelkova_Serrata",
]

species_to_idx = {name: i for i, name in enumerate(SPECIES)}

# ---------------------------------------------------------------
# Load data
# ---------------------------------------------------------------
train = pd.read_csv(os.path.join("input", "train.csv"))
test = pd.read_csv(os.path.join("input", "predict.csv"))

feature_cols = [c for c in train.columns if c not in ("id", "species")]
X = train[feature_cols].values
y = train["species"].astype(str).map(species_to_idx).values.astype(int)

X_test = test[feature_cols].values
test_ids = test["id"].values

# ---------------------------------------------------------------
# Validation split
# ---------------------------------------------------------------
Xtr, Xval, ytr, yval = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# ---------------------------------------------------------------
# Candidate models
# ---------------------------------------------------------------
models = {
    "RandomForest": RandomForestClassifier(
        n_estimators=500, min_samples_leaf=2, max_features="sqrt",
        n_jobs=2, random_state=42,
    ),
    "ExtraTrees": ExtraTreesClassifier(
        n_estimators=500, min_samples_leaf=2, max_features="sqrt",
        n_jobs=2, random_state=42,
    ),
    "LogisticRegression": Pipeline([
        ("scaler", StandardScaler()),
        ("clf", LogisticRegression(max_iter=2000, C=1.0)),
    ]),
    "kNN": Pipeline([
        ("scaler", StandardScaler()),
        ("clf", KNeighborsClassifier(n_neighbors=15, weights="distance", n_jobs=2)),
    ]),
    "SVM": Pipeline([
        ("scaler", StandardScaler()),
        ("clf", SVC(C=1.0, gamma="scale", probability=True)),
    ]),
}

# ---------------------------------------------------------------
# Select best model on validation log loss
# ---------------------------------------------------------------
best_name = None
best_model = None
best_loss = np.inf

for name, model in models.items():
    print(f"Training {name}...")
    model.fit(Xtr, ytr)
    p = model.predict_proba(Xval)
    p = np.clip(p, 1e-15, 1.0)
    p = p / p.sum(axis=1, keepdims=True)
    loss = log_loss(yval, p)
    print(f"  val log loss: {loss:.6f}")
    if loss < best_loss:
        best_loss = loss
        best_name = name
        best_model = model

print(f"Best model: {best_name} with raw val loss {best_loss:.6f}")

# ---------------------------------------------------------------
# Honest calibration: learn calibrators only on the training split.
# CalibratedClassifierCV uses internal 5-fold cross-fitting on Xtr,
# so the validation split is never used for fitting.
# ---------------------------------------------------------------
print("Fitting cross-validated sigmoid calibration on training split...")

cal_model = CalibratedClassifierCV(
    estimator=clone(best_model),
    cv=5,
    method="sigmoid",
)
cal_model.fit(Xtr, ytr)

val_probs = cal_model.predict_proba(Xval)
val_probs = np.clip(val_probs, 1e-15, 1.0)
val_probs = val_probs / val_probs.sum(axis=1, keepdims=True)
val_loss = log_loss(yval, val_probs)

print(f"Cross-validated calibrated val log loss: {val_loss:.6f}")

# ---------------------------------------------------------------
# Refit calibrated model on full training data and predict test
# ---------------------------------------------------------------
print("Refitting calibrated model on full training data...")

final_cal_model = CalibratedClassifierCV(
    estimator=clone(best_model),
    cv=5,
    method="sigmoid",
)
final_cal_model.fit(X, y)

test_probs = final_cal_model.predict_proba(X_test)
test_probs = np.clip(test_probs, 1e-15, 1.0)
test_probs = test_probs / test_probs.sum(axis=1, keepdims=True)

# ---------------------------------------------------------------
# Write submission
# ---------------------------------------------------------------
classes = final_cal_model.classes_
submission = pd.DataFrame({"id": test_ids})
for species in SPECIES:
    idx = species_to_idx[species]
    col = np.where(classes == idx)[0]
    if len(col) == 1:
        submission[species] = test_probs[:, col[0]]
    else:
        submission[species] = 0.0

submission.to_csv(os.path.join(OUTPUT_DIR, "predictions.csv"), index=False)

with open(os.path.join(OUTPUT_DIR, "val_score.json"), "w") as f:
    json.dump({"val_score": float(val_loss)}, f)

print("Done.")
