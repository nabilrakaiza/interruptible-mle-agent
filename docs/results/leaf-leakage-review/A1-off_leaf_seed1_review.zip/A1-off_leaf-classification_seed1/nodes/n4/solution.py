import os
import json

import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import log_loss

# The harness defines OUTPUT_DIR as the first line; only fall back if absent.
try:
    OUTPUT_DIR
except NameError:
    OUTPUT_DIR = "output"

INPUT_DIR = "input"

SPECIES = [
    "Acer_Capillipes", "Acer_Circinatum", "Acer_Mono", "Acer_Opalus",
    "Acer_Palmatum", "Acer_Pictum", "Acer_Platanoids", "Acer_Rubrum",
    "Acer_Rufinerve", "Acer_Saccharinum", "Alnus_Cordata", "Alnus_Maximowiczii",
    "Alnus_Rubra", "Alnus_Sieboldiana", "Alnus_Viridis", "Arundinaria_Simonii",
    "Betula_Austrosinensis", "Betula_Pendula", "Callicarpa_Bodinieri",
    "Castanea_Sativa", "Celtis_Koraiensis", "Cercis_Siliquastrum",
    "Cornus_Chinensis", "Cornus_Controversa", "Cornus_Macrophylla",
    "Cotinus_Coggygria", "Crataegus_Monogyna", "Cytisus_Battandieri",
    "Eucalyptus_Glaucescens", "Eucalyptus_Neglecta", "Eucalyptus_Urnigera",
    "Fagus_Sylvatica", "Ginkgo_Biloba", "Ilex_Aquifolium", "Ilex_Cornuta",
    "Liquidambar_Styraciflua", "Liriodendron_Tulipifera",
    "Lithocarpus_Cleistocarpus", "Lithocarpus_Edulis", "Magnolia_Heptapeta",
    "Magnolia_Salicifolia", "Morus_Nigra", "Olea_Europaea", "Phildelphus",
    "Populus_Adenopoda", "Populus_Grandidentata", "Populus_Nigra",
    "Prunus_Avium", "Prunus_X_Shmittii", "Pterocarya_Stenoptera",
    "Quercus_Afares", "Quercus_Agrifolia", "Quercus_Alnifolia",
    "Quercus_Brantii", "Quercus_Canariensis", "Quercus_Castaneifolia",
    "Quercus_Cerris", "Quercus_Chrysolepis", "Quercus_Coccifera",
    "Quercus_Coccinea", "Quercus_Crassifolia", "Quercus_Crassipes",
    "Quercus_Dolicholepis", "Quercus_Ellipsoidalis", "Quercus_Greggii",
    "Quercus_Hartwissiana", "Quercus_Ilex", "Quercus_Imbricaria",
    "Quercus_Infectoria_sub", "Quercus_Kewensis", "Quercus_Nigra",
    "Quercus_Palustris", "Quercus_Phellos", "Quercus_Phillyraeoides",
    "Quercus_Pontica", "Quercus_Pubescens", "Quercus_Pyrenaica",
    "Quercus_Rhysophylla", "Quercus_Rubra", "Quercus_Semecarpifolia",
    "Quercus_Shumardii", "Quercus_Suber", "Quercus_Texana", "Quercus_Trojana",
    "Quercus_Variabilis", "Quercus_Vulcanica", "Quercus_x_Hispanica",
    "Quercus_x_Turneri", "Rhododendron_x_Russellianum", "Salix_Fragilis",
    "Salix_Intergra", "Sorbus_Aria", "Tilia_Oliveri", "Tilia_Platyphyllos",
    "Tilia_Tomentosa", "Ulmus_Bergmanniana", "Viburnum_Tinus",
    "Viburnum_x_Rhytidophylloides", "Zelkova_Serrata",
]


def proba_for_species(model, X):
    """Return predict_proba as an array with columns in SPECIES order."""
    classes = model.named_steps["voting"].classes_
    proba = pd.DataFrame(model.predict_proba(X), columns=classes)
    proba = proba.reindex(columns=SPECIES, fill_value=0.0)
    proba = proba.div(proba.sum(axis=1), axis=0)
    return proba.to_numpy(dtype=np.float64)


def main():
    train_df = pd.read_csv(os.path.join(INPUT_DIR, "train.csv"))
    predict_df = pd.read_csv(os.path.join(INPUT_DIR, "predict.csv"))

    feature_cols = [c for c in predict_df.columns if c != "id"]

    X_all = train_df[feature_cols].to_numpy(dtype=np.float64)
    y_all = train_df["species"].to_numpy()
    X_test = predict_df[feature_cols].to_numpy(dtype=np.float64)
    test_ids = predict_df["id"].to_numpy()

    X_train_part, X_val, y_train_part, y_val = train_test_split(
        X_all, y_all, test_size=0.2, random_state=42, stratify=y_all
    )

    model = Pipeline([
        ("scaler", StandardScaler()),
        ("voting", VotingClassifier(
            estimators=[
                ("lr", LogisticRegression(
                    C=1.0, solver="lbfgs", max_iter=5000, random_state=42
                )),
                ("rf", RandomForestClassifier(
                    n_estimators=300,
                    min_samples_leaf=5,
                    max_features="sqrt",
                    n_jobs=2,
                    random_state=42,
                )),
                ("knn", KNeighborsClassifier(n_neighbors=40, weights="uniform")),
            ],
            voting="soft"
        )),
    ])

    model.fit(X_train_part, y_train_part)

    val_proba = proba_for_species(model, X_val)
    val_score = log_loss(y_val, val_proba)

    model.fit(X_all, y_all)

    test_proba = proba_for_species(model, X_test)
    submission = pd.DataFrame(test_proba, columns=SPECIES)
    submission.insert(0, "id", test_ids)

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    submission.to_csv(os.path.join(OUTPUT_DIR, "predictions.csv"), index=False)

    with open(os.path.join(OUTPUT_DIR, "val_score.json"), "w") as f:
        json.dump({"val_score": float(val_score)}, f)


if __name__ == "__main__":
    main()
