import os
import json
import warnings

import numpy as np
import pandas as pd

from sklearn.base import clone
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import log_loss

warnings.filterwarnings("ignore")

try:
    OUTPUT_DIR
except NameError:
    OUTPUT_DIR = "."

SPECIES = [
    "Acer_Capillipes", "Acer_Circinatum", "Acer_Mono", "Acer_Opalus",
    "Acer_Palmatum", "Acer_Pictum", "Acer_Platanoids", "Acer_Rubrum",
    "Acer_Rufinerve", "Acer_Saccharinum", "Alnus_Cordata", "Alnus_Maximowiczii",
    "Alnus_Rubra", "Alnus_Sieboldiana", "Alnus_Viridis", "Arundinaria_Simonii",
    "Betula_Austrosinensis", "Betula_Pendula", "Callicarpa_Bodinieri",
    "Castanea_Sativa", "Celtis_Koraiensis", "Cercis_Siliquastrum",
    "Cornus_Chinensis", "Cornus_Controversa", "Cornus_Macrophylla",
    "Cotinus_Coggygria", "Crataegus_Monogyna", "Cytisus_Battandieri",
    "Eucalyptus_Glaucescens", "Eucalyptus_Neglecta", "Eucalyptus_Urnigera",
    "Fagus_Sylvatica", "Ginkgo_Biloba", "Ilex_Aquifolium", "Ilex_Cornuta",
    "Liquidambar_Styraciflua", "Liriodendron_Tulipifera",
    "Lithocarpus_Cleistocarpus", "Lithocarpus_Edulis", "Magnolia_Heptapeta",
    "Magnolia_Salicifolia", "Morus_Nigra", "Olea_Europaea", "Phildelphus",
    "Populus_Adenopoda", "Populus_Grandidentata", "Populus_Nigra",
    "Prunus_Avium", "Prunus_X_Shmittii", "Pterocarya_Stenoptera",
    "Quercus_Afares", "Quercus_Agrifolia", "Quercus_Alnifolia",
    "Quercus_Brantii", "Quercus_Canariensis", "Quercus_Castaneifolia",
    "Quercus_Cerris", "Quercus_Chrysolepis", "Quercus_Coccifera",
    "Quercus_Coccinea", "Quercus_Crassifolia", "Quercus_Crassipes",
    "Quercus_Dolicholepis", "Quercus_Ellipsoidalis", "Quercus_Greggii",
    "Quercus_Hartwissiana", "Quercus_Ilex", "Quercus_Imbricaria",
    "Quercus_Infectoria_sub", "Quercus_Kewensis", "Quercus_Nigra",
    "Quercus_Palustris", "Quercus_Phellos", "Quercus_Phillyraeoides",
    "Quercus_Pontica", "Quercus_Pubescens", "Quercus_Pyrenaica",
    "Quercus_Rhysophylla", "Quercus_Rubra", "Quercus_Semecarpifolia",
    "Quercus_Shumardii", "Quercus_Suber", "Quercus_Texana",
    "Quercus_Trojana", "Quercus_Variabilis", "Quercus_Vulcanica",
    "Quercus_x_Hispanica", "Quercus_x_Turneri", "Rhododendron_x_Russellianum",
    "Salix_Fragilis", "Salix_Intergra", "Sorbus_Aria", "Tilia_Oliveri",
    "Tilia_Platyphyllos", "Tilia_Tomentosa", "Ulmus_Bergmanniana",
    "Viburnum_Tinus", "Viburnum_x_Rhytidophylloides", "Zelkova_Serrata",
]

species_to_idx = {name: i for i, name in enumerate(SPECIES)}

train = pd.read_csv(os.path.join("input", "train.csv"))
test = pd.read_csv(os.path.join("input", "predict.csv"))

feature_cols = [c for c in train.columns if c not in ("id", "species")]
X = train[feature_cols].values.astype(np.float64)
y = train["species"].astype(str).map(species_to_idx).values.astype(np.int64)

X_test = test[feature_cols].values.astype(np.float64)
test_ids = test["id"].values

n_classes = len(SPECIES)


def get_classes(estimator):
    if hasattr(estimator, "classes_"):
        return estimator.classes_
    for _, step in getattr(estimator, "named_steps", {}).items():
        if hasattr(step, "classes_"):
            return step.classes_
    raise RuntimeError("classes_ not found")


def normalize_rows(arr):
    row_sum = arr.sum(axis=1, keepdims=True)
    row_sum[row_sum == 0] = 1.0
    arr /= row_sum


base_specs = [
    (
        "lr",
        make_pipeline(
            StandardScaler(),
            LogisticRegression(solver="lbfgs", C=1.0, max_iter=2000, random_state=0),
        ),
    ),
    (
        "knn",
        make_pipeline(
            StandardScaler(),
            KNeighborsClassifier(n_neighbors=15, weights="distance", n_jobs=2),
        ),
    ),
    (
        "svm",
        make_pipeline(
            StandardScaler(),
            SVC(C=1.0, gamma="scale", probability=True, random_state=42),
        ),
    ),
    (
        "lda",
        make_pipeline(StandardScaler(), LinearDiscriminantAnalysis(solver="svd")),
    ),
]

n_models = len(base_specs)
n_splits = 5
kf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)

n = X.shape[0]
n_test = X_test.shape[0]

oof = np.zeros((n, n_models, n_classes), dtype=np.float64)
test_fold = np.zeros((n_splits, n_test, n_models, n_classes), dtype=np.float64)

for fold, (tr_idx, va_idx) in enumerate(kf.split(X, y)):
    for m_idx, (_, spec) in enumerate(base_specs):
        model = clone(spec)
        model.fit(X[tr_idx], y[tr_idx])

        p_va = model.predict_proba(X[va_idx])
        p_te = model.predict_proba(X_test)

        for j, c in enumerate(get_classes(model)):
            col = int(c)
            oof[va_idx, m_idx, col] = p_va[:, j]
            test_fold[fold, :, m_idx, col] = p_te[:, j]

    print(f"Base fold {fold + 1}/{n_splits} done.")

for m_idx in range(n_models):
    normalize_rows(oof[:, m_idx, :])

for fold in range(n_splits):
    for m_idx in range(n_models):
        normalize_rows(test_fold[fold, :, m_idx, :])

meta_oof = np.concatenate([oof[:, m_idx, :] for m_idx in range(n_models)], axis=1)

stacker = make_pipeline(
    StandardScaler(),
    LogisticRegression(solver="lbfgs", C=1.0, max_iter=1000, random_state=0),
)


def nested_stack_predict(estimator, X_meta, y_meta):
    pred = np.zeros((X_meta.shape[0], n_classes), dtype=np.float64)
    for tr_idx, va_idx in kf.split(X_meta, y_meta):
        est = clone(estimator)
        est.fit(X_meta[tr_idx], y_meta[tr_idx])
        p = est.predict_proba(X_meta[va_idx])
        for j, c in enumerate(get_classes(est)):
            pred[va_idx, int(c)] = p[:, j]
    return pred


val_probs = nested_stack_predict(stacker, meta_oof, y)
val_probs = np.clip(val_probs, 1e-15, 1.0)
normalize_rows(val_probs)
val_score = log_loss(y, val_probs)
print(f"Validation log loss: {val_score:.6f}")

stacker.fit(meta_oof, y)

test_probs = np.zeros((n_test, n_classes), dtype=np.float64)

for fold in range(n_splits):
    fold_meta = np.concatenate(
        [test_fold[fold, :, m_idx, :] for m_idx in range(n_models)], axis=1
    )
    p_fold = stacker.predict_proba(fold_meta)
    fold_probs = np.zeros_like(p_fold)
    for j, c in enumerate(get_classes(stacker)):
        fold_probs[:, int(c)] = p_fold[:, j]
    test_probs += fold_probs / n_splits

test_probs = np.clip(test_probs, 1e-15, 1.0)
normalize_rows(test_probs)

os.makedirs(OUTPUT_DIR, exist_ok=True)

submission = pd.DataFrame({"id": test_ids})
for idx, species in enumerate(SPECIES):
    submission[species] = test_probs[:, idx]

submission.to_csv(os.path.join(OUTPUT_DIR, "predictions.csv"), index=False)

with open(os.path.join(OUTPUT_DIR, "val_score.json"), "w") as f:
    json.dump({"val_score": float(val_score)}, f)

print("Done.")
