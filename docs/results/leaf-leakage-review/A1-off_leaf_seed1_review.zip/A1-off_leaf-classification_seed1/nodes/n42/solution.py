import os
import json
import re
import warnings

import numpy as np
import pandas as pd
from sklearn.ensemble import StackingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore")

if "OUTPUT_DIR" not in globals():
    OUTPUT_DIR = os.environ.get("OUTPUT_DIR", ".")
os.makedirs(OUTPUT_DIR, exist_ok=True)


def get_feature_columns(df):
    cols = []
    for prefix in ("margin", "shape", "texture"):
        matched = [
            c for c in df.columns
            if re.fullmatch(re.escape(prefix) + r"_?\d+", c)
        ]
        matched.sort(key=lambda c: int(re.search(r"\d+$", c).group(0)))
        cols.extend(matched)
    return cols


train = pd.read_csv("input/train.csv")
predict = pd.read_csv("input/predict.csv")

feature_cols = get_feature_columns(train)
if len(feature_cols) != 192:
    feature_cols = [f"{p}{i}" for p in ("margin", "shape", "texture") for i in range(1, 65)]

train["species"] = train["species"].astype(str).str.strip()
species_list = sorted(train["species"].unique())
assert len(species_list) == 99, f"Expected 99 species, got {len(species_list)}"
species_to_idx = {s: i for i, s in enumerate(species_list)}

X = train[feature_cols].to_numpy(dtype=np.float64)
y = train["species"].map(species_to_idx).to_numpy(dtype=np.int64)
X_test = predict[feature_cols].to_numpy(dtype=np.float64)

X_train, X_val, y_train, y_val = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

base_estimators = [
    ("lr", Pipeline([
        ("scale", StandardScaler()),
        ("lr", LogisticRegression(C=1.0, max_iter=1000, tol=1e-4)),
    ])),
    ("knn", Pipeline([
        ("scale", StandardScaler()),
        ("knn", KNeighborsClassifier(n_neighbors=15, weights="distance")),
    ])),
    ("mlp", Pipeline([
        ("scale", StandardScaler()),
        ("mlp", MLPClassifier(
            hidden_layer_sizes=(64,),
            alpha=0.01,
            max_iter=500,
            early_stopping=True,
            n_iter_no_change=10,
            random_state=42,
        )),
    ])),
]

model = StackingClassifier(
    estimators=base_estimators,
    # Stronger L2 regularization on the meta-learner to avoid overfitting
    # the high-dimensional out-of-fold probability features.
    final_estimator=LogisticRegression(C=0.01, max_iter=1000, tol=1e-4),
    cv=cv,
    stack_method="predict_proba",
    n_jobs=1,
    passthrough=False,
)

n_classes = len(species_list)

model.fit(X_train, y_train)
val_proba = model.predict_proba(X_val)
val_proba = np.clip(val_proba, 1e-15, 1.0)
val_proba = val_proba / val_proba.sum(axis=1, keepdims=True)
val_score = log_loss(y_val, val_proba, labels=np.arange(n_classes))
print(f"Validation log loss: {val_score:.6f}")

model.fit(X, y)
test_proba = model.predict_proba(X_test)
test_proba = np.clip(test_proba, 1e-15, 1.0)
test_proba = test_proba / test_proba.sum(axis=1, keepdims=True)

submission = pd.DataFrame(test_proba, columns=species_list)
submission.insert(0, "id", predict["id"].values)
submission.to_csv(os.path.join(OUTPUT_DIR, "predictions.csv"), index=False)

with open(os.path.join(OUTPUT_DIR, "val_score.json"), "w") as f:
    json.dump({"val_score": float(val_score)}, f)
