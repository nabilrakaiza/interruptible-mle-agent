import os
import json
import warnings

import numpy as np
import pandas as pd

from PIL import Image
from scipy.ndimage import binary_erosion
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.metrics import log_loss
from sklearn.base import clone
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC

warnings.filterwarnings("ignore")

try:
    OUTPUT_DIR
except NameError:
    OUTPUT_DIR = "."

SPECIES = [
    "Acer_Capillipes", "Acer_Circinatum", "Acer_Mono", "Acer_Opalus",
    "Acer_Palmatum", "Acer_Pictum", "Acer_Platanoids", "Acer_Rubrum",
    "Acer_Rufinerve", "Acer_Saccharinum", "Alnus_Cordata", "Alnus_Maximowiczii",
    "Alnus_Rubra", "Alnus_Sieboldiana", "Alnus_Viridis", "Arundinaria_Simonii",
    "Betula_Austrosinensis", "Betula_Pendula", "Callicarpa_Bodinieri",
    "Castanea_Sativa", "Celtis_Koraiensis", "Cercis_Siliquastrum",
    "Cornus_Chinensis", "Cornus_Controversa", "Cornus_Macrophylla",
    "Cotinus_Coggygria", "Crataegus_Monogyna", "Cytisus_Battandieri",
    "Eucalyptus_Glaucescens", "Eucalyptus_Neglecta", "Eucalyptus_Urnigera",
    "Fagus_Sylvatica", "Ginkgo_Biloba", "Ilex_Aquifolium", "Ilex_Cornuta",
    "Liquidambar_Styraciflua", "Liriodendron_Tulipifera",
    "Lithocarpus_Cleistocarpus", "Lithocarpus_Edulis", "Magnolia_Heptapeta",
    "Magnolia_Salicifolia", "Morus_Nigra", "Olea_Europaea", "Phildelphus",
    "Populus_Adenopoda", "Populus_Grandidentata", "Populus_Nigra",
    "Prunus_Avium", "Prunus_X_Shmittii", "Pterocarya_Stenoptera",
    "Quercus_Afares", "Quercus_Agrifolia", "Quercus_Alnifolia",
    "Quercus_Brantii", "Quercus_Canariensis", "Quercus_Castaneifolia",
    "Quercus_Cerris", "Quercus_Chrysolepis", "Quercus_Coccifera",
    "Quercus_Coccinea", "Quercus_Crassifolia", "Quercus_Crassipes",
    "Quercus_Dolicholepis", "Quercus_Ellipsoidalis", "Quercus_Greggii",
    "Quercus_Hartwissiana", "Quercus_Ilex", "Quercus_Imbricaria",
    "Quercus_Infectoria_sub", "Quercus_Kewensis", "Quercus_Nigra",
    "Quercus_Palustris", "Quercus_Phellos", "Quercus_Phillyraeoides",
    "Quercus_Pontica", "Quercus_Pubescens", "Quercus_Pyrenaica",
    "Quercus_Rhysophylla", "Quercus_Rubra", "Quercus_Semecarpifolia",
    "Quercus_Shumardii", "Quercus_Suber", "Quercus_Texana",
    "Quercus_Trojana", "Quercus_Variabilis", "Quercus_Vulcanica",
    "Quercus_x_Hispanica", "Quercus_x_Turneri", "Rhododendron_x_Russellianum",
    "Salix_Fragilis", "Salix_Intergra", "Sorbus_Aria", "Tilia_Oliveri",
    "Tilia_Platyphyllos", "Tilia_Tomentosa", "Ulmus_Bergmanniana",
    "Viburnum_Tinus", "Viburnum_x_Rhytidophylloides", "Zelkova_Serrata",
]

species_to_idx = {name: i for i, name in enumerate(SPECIES)}


# ---------------------------------------------------------------
# Image feature extraction
# ---------------------------------------------------------------
def _center_of_mass(crop):
    total = crop.sum()
    if total == 0:
        return 0.0, 0.0
    rows = np.arange(crop.shape[0], dtype=np.float64)
    cols = np.arange(crop.shape[1], dtype=np.float64)
    cy = (crop.sum(axis=1) @ rows) / float(total)
    cx = (crop.sum(axis=0) @ cols) / float(total)
    return cy, cx


def _moments_central(crop, cy, cx, order=3):
    h, w = crop.shape
    y = np.arange(h, dtype=np.float64) - cy
    x = np.arange(w, dtype=np.float64) - cx
    yp = np.ones((h, order + 1), dtype=np.float64)
    xp = np.ones((w, order + 1), dtype=np.float64)
    for p in range(1, order + 1):
        yp[:, p] = yp[:, p - 1] * y
        xp[:, p] = xp[:, p - 1] * x
    return yp.T @ crop.astype(np.float64) @ xp


def extract_image_features(path):
    default = np.zeros(12, dtype=np.float64)
    if not os.path.exists(path):
        return default
    try:
        with Image.open(path) as im:
            img = np.array(im.convert("L"))
    except Exception:
        return default
    if img.size == 0:
        return default

    # Binary black leaf on white background; invert if necessary.
    mask = img < 128
    if mask.mean() > 0.5:
        mask = ~mask

    coords = np.argwhere(mask)
    if coords.size == 0:
        return default

    min_y, max_y = coords[:, 0].min(), coords[:, 0].max()
    min_x, max_x = coords[:, 1].min(), coords[:, 1].max()
    crop = mask[min_y:max_y + 1, min_x:max_x + 1]
    h, w = crop.shape
    area = float(crop.sum())
    if area <= 0:
        return default

    bbox_area = float(h * w)
    extent = area / bbox_area
    aspect = w / h if h > 0 else 1.0

    eroded = binary_erosion(crop, iterations=1)
    perimeter = float((crop & ~eroded).sum())

    cy, cx = _center_of_mass(crop)
    mu = _moments_central(crop, cy, cx, 3)

    # Eccentricity from second moments.
    mu20, mu02, mu11 = mu[2, 0], mu[0, 2], mu[1, 1]
    cov00, cov11 = mu20 / area, mu02 / area
    cov01 = mu11 / area
    trace = cov00 + cov11
    disc = 0.25 * (cov00 - cov11) ** 2 + cov01 ** 2
    major = np.sqrt(max(0.0, 0.5 * (trace + np.sqrt(disc))))
    minor = np.sqrt(max(0.0, 0.5 * (trace - np.sqrt(disc))))
    ecc = 0.0
    if major > 1e-12:
        ecc = np.sqrt(max(0.0, 1.0 - (minor / major) ** 2))

    # Normalized central moments.
    nu = {}
    for p in range(4):
        for q in range(4 - p):
            if p + q >= 2:
                nu[(p, q)] = mu[p, q] / (area ** (1.0 + (p + q) / 2.0))

    # Hu moments.
    n20, n02, n11 = nu[(2, 0)], nu[(0, 2)], nu[(1, 1)]
    n30, n12 = nu[(3, 0)], nu[(1, 2)]
    n21, n03 = nu[(2, 1)], nu[(0, 3)]
    hu = np.zeros(7)
    hu[0] = n20 + n02
    hu[1] = (n20 - n02) ** 2 + 4 * n11 ** 2
    hu[2] = (n30 - 3 * n12) ** 2 + (3 * n21 - n03) ** 2
    hu[3] = (n30 + n12) ** 2 + (n21 + n03) ** 2
    hu[4] = ((n30 - 3 * n12) * (n30 + n12) *
             ((n30 + n12) ** 2 - 3 * (n21 + n03) ** 2) +
             (3 * n21 - n03) * (n21 + n03) *
             (3 * (n30 + n12) ** 2 - (n21 + n03) ** 2))
    hu[5] = ((n20 - n02) * ((n30 + n12) ** 2 - (n21 + n03) ** 2) +
             4 * n11 * (n30 + n12) * (n21 + n03))
    hu[6] = ((3 * n21 - n03) * (n30 + n12) *
             ((n30 + n12) ** 2 - 3 * (n21 + n03) ** 2) -
             (n30 - 3 * n12) * (n21 + n03) *
             (3 * (n30 + n12) ** 2 - (n21 + n03) ** 2))
    hu_log = np.sign(hu) * np.log10(np.abs(hu) + 1e-10)

    return np.array([
        np.log1p(area),
        np.log1p(perimeter),
        aspect,
        extent,
        ecc,
        hu_log[0],
        hu_log[1],
        hu_log[2],
        hu_log[3],
        hu_log[4],
        hu_log[5],
        hu_log[6],
    ], dtype=np.float64)


def load_image_features(df):
    feats = []
    for img_id in df["id"]:
        path = os.path.join("input", "images", f"{int(img_id)}.jpg")
        feats.append(extract_image_features(path))
    return np.array(feats, dtype=np.float64)


# ---------------------------------------------------------------
# Load data
# ---------------------------------------------------------------
train = pd.read_csv(os.path.join("input", "train.csv"))
test = pd.read_csv(os.path.join("input", "predict.csv"))

feature_cols = [c for c in train.columns if c not in ("id", "species")]
X_pre = train[feature_cols].values
y = train["species"].astype(str).map(species_to_idx).values.astype(int)

X_test_pre = test[feature_cols].values
test_ids = test["id"].values

print("Extracting image features...")
img_train = load_image_features(train)
img_train_mean = img_train.mean(axis=0)
missing_train = np.all(img_train == 0, axis=1)
if missing_train.any():
    img_train[missing_train] = img_train_mean

img_test = load_image_features(test)
missing_test = np.all(img_test == 0, axis=1)
if missing_test.any():
    img_test[missing_test] = img_train_mean

X = np.hstack([X_pre, img_train])
X_test = np.hstack([X_test_pre, img_test])

# ---------------------------------------------------------------
# Validation split
# ---------------------------------------------------------------
Xtr, Xval, ytr, yval = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)


# ---------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------
def safe_probs(p):
    p = np.clip(p, 1e-15, 1.0)
    return p / p.sum(axis=1, keepdims=True)


def oof_probabilities(estimator, X, y, n_splits=5, random_state=42):
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=random_state)
    proba = np.zeros((X.shape[0], len(np.unique(y))))
    for train_idx, val_idx in skf.split(X, y):
        est = clone(estimator)
        est.fit(X[train_idx], y[train_idx])
        p = est.predict_proba(X[val_idx])
        proba[val_idx] = safe_probs(p)
    return proba


# ---------------------------------------------------------------
# Base models
# ---------------------------------------------------------------
lda = LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto")
lr = Pipeline([
    ("scaler", StandardScaler()),
    ("clf", LogisticRegression(solver="lbfgs", max_iter=2000, C=1.0, random_state=42)),
])
knn = Pipeline([
    ("scaler", StandardScaler()),
    ("clf", KNeighborsClassifier(n_neighbors=7, weights="distance")),
])
svm = Pipeline([
    ("scaler", StandardScaler()),
    ("clf", SVC(C=1.0, gamma="scale", probability=True, random_state=42)),
])

# ---------------------------------------------------------------
# Fit stacked calibration on out-of-fold probabilities
# ---------------------------------------------------------------
print("Computing out-of-fold probabilities for the validation split...")
lda_oof = oof_probabilities(lda, Xtr, ytr)
lr_oof = oof_probabilities(lr, Xtr, ytr)
knn_oof = oof_probabilities(knn, Xtr, ytr)
svm_oof = oof_probabilities(svm, Xtr, ytr)
print(f"  OOF LDA log loss: {log_loss(ytr, lda_oof):.6f}")
print(f"  OOF LR log loss:  {log_loss(ytr, lr_oof):.6f}")
print(f"  OOF KNN log loss: {log_loss(ytr, knn_oof):.6f}")
print(f"  OOF SVM log loss: {log_loss(ytr, svm_oof):.6f}")

stack_train = np.hstack([lda_oof, lr_oof, knn_oof, svm_oof])

meta = Pipeline([
    ("scaler", StandardScaler()),
    ("clf", LogisticRegression(solver="lbfgs", C=0.1, max_iter=2000, random_state=42)),
])
meta.fit(stack_train, ytr)

# ---------------------------------------------------------------
# Honest validation score: stack trained only on the training split
# ---------------------------------------------------------------
val_lda = safe_probs(clone(lda).fit(Xtr, ytr).predict_proba(Xval))
val_lr = safe_probs(clone(lr).fit(Xtr, ytr).predict_proba(Xval))
val_knn = safe_probs(clone(knn).fit(Xtr, ytr).predict_proba(Xval))
val_svm = safe_probs(clone(svm).fit(Xtr, ytr).predict_proba(Xval))
stack_val = np.hstack([val_lda, val_lr, val_knn, val_svm])
val_probs = safe_probs(meta.predict_proba(stack_val))
cal_loss = log_loss(yval, val_probs)
print(f"Stacked validation log loss: {cal_loss:.6f}")

# ---------------------------------------------------------------
# Refit stack on full training data and predict test
# ---------------------------------------------------------------
print("Fitting full-data stack for test predictions...")
lda_oof_full = oof_probabilities(lda, X, y)
lr_oof_full = oof_probabilities(lr, X, y)
knn_oof_full = oof_probabilities(knn, X, y)
svm_oof_full = oof_probabilities(svm, X, y)
stack_full = np.hstack([lda_oof_full, lr_oof_full, knn_oof_full, svm_oof_full])

meta_full = clone(meta)
meta_full.fit(stack_full, y)

lda_full = clone(lda).fit(X, y)
lr_full = clone(lr).fit(X, y)
knn_full = clone(knn).fit(X, y)
svm_full = clone(svm).fit(X, y)

test_lda = safe_probs(lda_full.predict_proba(X_test))
test_lr = safe_probs(lr_full.predict_proba(X_test))
test_knn = safe_probs(knn_full.predict_proba(X_test))
test_svm = safe_probs(svm_full.predict_proba(X_test))
test_probs = safe_probs(meta_full.predict_proba(np.hstack([test_lda, test_lr, test_knn, test_svm])))

# ---------------------------------------------------------------
# Write submission
# ---------------------------------------------------------------
submission = pd.DataFrame({"id": test_ids})
for i, species in enumerate(SPECIES):
    submission[species] = test_probs[:, i]

submission.to_csv(os.path.join(OUTPUT_DIR, "predictions.csv"), index=False)

with open(os.path.join(OUTPUT_DIR, "val_score.json"), "w") as f:
    json.dump({"val_score": float(cal_loss)}, f)

print("Done.")
